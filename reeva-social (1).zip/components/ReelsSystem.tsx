'use client';

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Image from 'next/image';
import { 
  Heart, 
  MessageCircle, 
  Share2, 
  MoreVertical, 
  Music, 
  Volume2, 
  VolumeX,
  Play,
  Pause
} from 'lucide-react';

interface Reel {
  id: string;
  videoUrl: string;
  user: {
    name: string;
    avatar: string;
    isFollowing: boolean;
  };
  caption: string;
  musicName: string;
  likes: string;
  comments: string;
}

const MOCK_REELS: Reel[] = [
  {
    id: '1',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-girl-in-neon-light-1282-large.mp4',
    user: { name: 'Luna Digital', avatar: 'https://picsum.photos/seed/luna/100', isFollowing: false },
    caption: 'Neon vibes in the city tonight 🌃✨ #neon #cyberpunk #citylife',
    musicName: 'Cyberpunk 2077 - Original Soundtrack',
    likes: '45.2k',
    comments: '1.2k'
  },
  {
    id: '2',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-tree-with-yellow-leaves-low-angle-shot-1571-large.mp4',
    user: { name: 'Nature Explorer', avatar: 'https://picsum.photos/seed/nature/100', isFollowing: true },
    caption: 'Autumn is finally here! 🍂 The colors are just breathtaking.',
    musicName: 'Vivaldi - Four Seasons (Autumn)',
    likes: '12.8k',
    comments: '450'
  }
];

export default function ReelsSystem() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isPlaying, setIsPlaying] = useState(true);
  const videoRefs = useRef<(HTMLVideoElement | null)[]>([]);

  useEffect(() => {
    videoRefs.current.forEach((video, idx) => {
      if (video) {
        if (idx === activeIndex) {
          video.play().catch(() => {});
        } else {
          video.pause();
          video.currentTime = 0;
        }
      }
    });
  }, [activeIndex]);

  const togglePlay = () => {
    const currentVideo = videoRefs.current[activeIndex];
    if (currentVideo) {
      if (isPlaying) {
        currentVideo.pause();
      } else {
        currentVideo.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  return (
    <div className="h-[calc(100vh-180px)] max-w-md mx-auto relative bg-black rounded-[40px] overflow-hidden shadow-2xl border border-white/10">
      <div 
        className="h-full overflow-y-scroll snap-y snap-mandatory scrollbar-hide"
        onScroll={(e) => {
          const index = Math.round(e.currentTarget.scrollTop / e.currentTarget.clientHeight);
          if (index !== activeIndex) setActiveIndex(index);
        }}
      >
        {MOCK_REELS.map((reel, idx) => (
          <div key={reel.id} className="h-full w-full snap-start relative">
            {/* Video Background */}
            <video
              ref={(el) => { videoRefs.current[idx] = el; }}
              src={reel.videoUrl}
              className="h-full w-full object-cover"
              loop
              muted={isMuted}
              playsInline
              onClick={togglePlay}
            />

            {/* Overlay Gradient */}
            <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/60 pointer-events-none" />

            {/* Controls Overlay */}
            <div className="absolute inset-0 p-6 flex flex-col justify-end pointer-events-none">
              <div className="flex justify-between items-end pointer-events-auto">
                {/* Left Side: Info */}
                <div className="flex-1 pr-12 space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="relative w-10 h-10 rounded-full border-2 border-white overflow-hidden">
                      <Image src={reel.user.avatar} alt={reel.user.name} fill className="object-cover" referrerPolicy="no-referrer" />
                    </div>
                    <span className="font-bold text-white text-sm">{reel.user.name}</span>
                    {!reel.user.isFollowing && (
                      <button className="px-3 py-1 bg-white/20 backdrop-blur-md rounded-lg text-[10px] font-bold text-white border border-white/20">
                        Follow
                      </button>
                    )}
                  </div>
                  <p className="text-sm text-white/90 line-clamp-2">{reel.caption}</p>
                  <div className="flex items-center gap-2 text-white/70">
                    <Music className="w-3 h-3 animate-spin-slow" />
                    <span className="text-[10px] font-medium truncate">{reel.musicName}</span>
                  </div>
                </div>

                {/* Right Side: Actions */}
                <div className="flex flex-col gap-6 items-center">
                  <button className="flex flex-col items-center gap-1 group">
                    <div className="p-3 bg-white/10 backdrop-blur-xl rounded-full group-hover:bg-rose-500/20 transition-all">
                      <Heart className="w-6 h-6 text-white group-hover:text-rose-500 transition-colors" />
                    </div>
                    <span className="text-[10px] font-bold text-white">{reel.likes}</span>
                  </button>
                  <button className="flex flex-col items-center gap-1 group">
                    <div className="p-3 bg-white/10 backdrop-blur-xl rounded-full group-hover:bg-indigo-500/20 transition-all">
                      <MessageCircle className="w-6 h-6 text-white group-hover:text-indigo-500 transition-colors" />
                    </div>
                    <span className="text-[10px] font-bold text-white">{reel.comments}</span>
                  </button>
                  <button className="p-3 bg-white/10 backdrop-blur-xl rounded-full hover:bg-white/20 transition-all">
                    <Share2 className="w-6 h-6 text-white" />
                  </button>
                  <button className="p-3 bg-white/10 backdrop-blur-xl rounded-full hover:bg-white/20 transition-all">
                    <MoreVertical className="w-6 h-6 text-white" />
                  </button>
                  <div className="w-8 h-8 rounded-lg bg-zinc-800 border border-white/20 overflow-hidden animate-spin-slow">
                    <Image src={reel.user.avatar} alt="music disk" fill className="object-cover" referrerPolicy="no-referrer" />
                  </div>
                </div>
              </div>
            </div>

            {/* Mute/Play Status Indicators */}
            <div className="absolute top-6 right-6 flex gap-2 pointer-events-auto">
              <button 
                onClick={() => setIsMuted(!isMuted)}
                className="p-2 bg-black/20 backdrop-blur-md rounded-full text-white border border-white/10"
              >
                {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
              </button>
            </div>
            
            <AnimatePresence>
              {!isPlaying && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.5 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.5 }}
                  className="absolute inset-0 flex items-center justify-center pointer-events-none"
                >
                  <div className="p-6 bg-black/40 backdrop-blur-md rounded-full">
                    <Pause className="w-12 h-12 text-white fill-current" />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>
    </div>
  );
}
