'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage, Language } from '@/contexts/LanguageContext';
import { 
  User, Lock, Bell, Eye, Moon, Languages, HelpCircle, LogOut,
  ChevronRight, Shield, Smartphone, Ban, VolumeX, MessageSquareOff,
  Filter, AlertTriangle, ChevronLeft, Check, Key, Archive, Bookmark,
  Flag, FileText, Upload, Mail, Phone, ShieldCheck, Globe
} from 'lucide-react';

export default function GeneralSettings({ theme, setTheme, onEditProfile }: { 
  theme: 'dark' | 'light', 
  setTheme: (t: 'dark' | 'light') => void,
  onEditProfile?: () => void 
}) {
  const [activeSubView, setActiveSubView] = useState<'main' | 'safety' | 'language' | 'notifications' | 'privacy' | 'security' | 'archive' | 'saved' | 'reports' | 'guidelines' | 'personal_info'>('main');
  const { lang, setLang, t } = useLanguage();

  const languages = [
    { code: 'en', name: 'English', flag: '🇺🇸' },
    { code: 'ar', name: 'العربية', flag: '🇦🇪' },
    { code: 'fr', name: 'Français', flag: '🇫🇷' },
    { code: 'es', name: 'Español', flag: '🇪🇸' },
    { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
    { code: 'zh', name: '中文', flag: '🇨🇳' },
    { code: 'ja', name: '日本語', flag: '🇯🇵' },
  ];

  const sections = [
    {
      title: 'Account Settings',
      items: [
        { id: 'personal_info', label: 'Personal Information', icon: <User className="w-5 h-5" />, desc: 'Email, phone, and account verification', action: () => setActiveSubView('personal_info') },
        { id: 'profile', label: 'Edit Profile', icon: <User className="w-5 h-5" />, desc: 'Change your avatar, bio, and name', action: onEditProfile },
        { id: 'security', label: 'Password & Security', icon: <Key className="w-5 h-5" />, desc: 'Change password and manage 2FA', action: () => setActiveSubView('security') },
        { id: 'devices', label: 'Logged Devices', icon: <Smartphone className="w-5 h-5" />, desc: 'Check where you are logged in' },
      ]
    },
    {
      title: 'Preferences',
      items: [
        { id: 'notifications', label: 'Notifications', icon: <Bell className="w-5 h-5" />, desc: 'Push, email, and SMS alerts', action: () => setActiveSubView('notifications') },
        { id: 'language', label: 'Language', icon: <Languages className="w-5 h-5" />, desc: 'Select your preferred language', action: () => setActiveSubView('language') },
        { id: 'saved', label: 'Saved Items', icon: <Bookmark className="w-5 h-5" />, desc: 'View your saved posts and collections', action: () => setActiveSubView('saved') },
        { id: 'archive', label: 'Archive', icon: <Archive className="w-5 h-5" />, desc: 'Archived posts and stories', action: () => setActiveSubView('archive') },
      ]
    },
    {
      title: 'Safety & Privacy',
      items: [
        { id: 'privacy', label: 'Privacy Settings', icon: <Eye className="w-5 h-5" />, desc: 'Control who can see your content', action: () => setActiveSubView('privacy') },
        { id: 'safety', label: 'Safety & Social Control', icon: <Lock className="w-5 h-5" />, desc: 'Manage blocked and restricted users', action: () => setActiveSubView('safety') },
      ]
    },
    {
      title: 'Support & About',
      items: [
        { id: 'reports', label: 'Reports & Issues', icon: <Flag className="w-5 h-5" />, desc: 'Report app issues or user violations', action: () => setActiveSubView('reports') },
        { id: 'guidelines', label: 'Community Guidelines', icon: <FileText className="w-5 h-5" />, desc: 'Rules and policies for your region', action: () => setActiveSubView('guidelines') },
      ]
    }
  ];

  const renderHeader = (title: string, desc: string) => (
    <>
      <button 
        onClick={() => setActiveSubView('main')}
        className="flex items-center gap-2 text-zinc-400 hover:text-white transition-colors mb-4"
      >
        <ChevronLeft className="w-5 h-5" />
        Back to Settings
      </button>
      <header className="space-y-2 mb-8">
        <h2 className="text-2xl font-bold text-white">{title}</h2>
        <p className="text-zinc-500 text-sm">{desc}</p>
      </header>
    </>
  );

  if (activeSubView === 'personal_info') {
    return (
      <div className="max-w-2xl mx-auto p-4 space-y-6">
        {renderHeader('Personal Information', 'Manage your contact details and account security level.')}
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-white/5 border border-white/5">
            <div className="flex items-center gap-4 mb-4">
              <div className="p-2 rounded-xl bg-zinc-900 text-indigo-400"><Mail className="w-5 h-5" /></div>
              <div className="flex-1">
                <p className="text-sm font-medium text-white">Email Address</p>
                <p className="text-xs text-zinc-500">user@example.com</p>
              </div>
              <button className="text-xs font-bold text-indigo-400">Edit</button>
            </div>
            <div className="flex items-center gap-4 pt-4 border-t border-white/5">
              <div className="p-2 rounded-xl bg-zinc-900 text-emerald-400"><Phone className="w-5 h-5" /></div>
              <div className="flex-1">
                <p className="text-sm font-medium text-white">Phone Number</p>
                <p className="text-xs text-zinc-500">+971 50 123 4567</p>
              </div>
              <button className="text-xs font-bold text-indigo-400">Edit</button>
            </div>
          </div>
          <div className="p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/20">
            <div className="flex items-center gap-3 mb-2">
              <ShieldCheck className="w-5 h-5 text-indigo-400" />
              <h3 className="text-sm font-bold text-white">Security Level: High</h3>
            </div>
            <p className="text-xs text-zinc-400 leading-relaxed">
              Your account is secured by linking your phone number according to your region&apos;s security standards. This helps prevent unauthorized access and account recovery.
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (activeSubView === 'security') {
    return (
      <div className="max-w-2xl mx-auto p-4 space-y-6">
        {renderHeader('Password & Security', 'Update your password and manage two-factor authentication.')}
        <div className="space-y-4">
          <div className="space-y-2">
            <input type="password" placeholder="Current Password" className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-white placeholder-zinc-500 focus:outline-none focus:border-indigo-500/50" />
            <input type="password" placeholder="New Password" className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-white placeholder-zinc-500 focus:outline-none focus:border-indigo-500/50" />
            <input type="password" placeholder="Confirm New Password" className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-white placeholder-zinc-500 focus:outline-none focus:border-indigo-500/50" />
            <button className="w-full py-4 bg-indigo-500 rounded-xl text-white font-bold mt-2 hover:bg-indigo-600 transition-colors">Update Password</button>
          </div>
          <div className="p-4 rounded-2xl bg-white/5 border border-white/5 mt-8">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-white">Two-Factor Authentication</p>
                <p className="text-xs text-zinc-500">Add an extra layer of security</p>
              </div>
              <button className="px-4 py-2 bg-white/10 rounded-lg text-sm font-bold text-white hover:bg-white/20">Enable</button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (activeSubView === 'notifications') {
    return (
      <div className="max-w-2xl mx-auto p-4 space-y-6">
        {renderHeader('Notifications', 'Choose what you want to be notified about.')}
        <div className="space-y-2">
          {['Push Notifications', 'Email Notifications', 'SMS Notifications', 'Likes & Comments', 'New Followers', 'Direct Messages'].map(item => (
            <div key={item} className="flex items-center justify-between p-4 rounded-2xl bg-white/5 border border-white/5">
              <span className="text-sm font-medium text-white">{item}</span>
              <div className="relative w-12 h-6 bg-indigo-500 rounded-full cursor-pointer">
                <div className="absolute top-1 right-1 w-4 h-4 bg-white rounded-full shadow-lg" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (activeSubView === 'privacy') {
    return (
      <div className="max-w-2xl mx-auto p-4 space-y-6">
        {renderHeader('Privacy Settings', 'Control who can see your content and interact with you.')}
        <div className="space-y-2">
          <div className="flex items-center justify-between p-4 rounded-2xl bg-white/5 border border-white/5">
            <div>
              <p className="text-sm font-medium text-white">Private Account</p>
              <p className="text-xs text-zinc-500">Only approved followers can see your posts</p>
            </div>
            <div className="relative w-12 h-6 bg-zinc-700 rounded-full cursor-pointer">
              <div className="absolute top-1 left-1 w-4 h-4 bg-white rounded-full shadow-lg" />
            </div>
          </div>
          <div className="flex items-center justify-between p-4 rounded-2xl bg-white/5 border border-white/5">
            <div>
              <p className="text-sm font-medium text-white">Activity Status</p>
              <p className="text-xs text-zinc-500">Show when you are active</p>
            </div>
            <div className="relative w-12 h-6 bg-indigo-500 rounded-full cursor-pointer">
              <div className="absolute top-1 right-1 w-4 h-4 bg-white rounded-full shadow-lg" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (activeSubView === 'reports') {
    return (
      <div className="max-w-2xl mx-auto p-4 space-y-6">
        {renderHeader('Reports & Issues', 'Report problems with the app or other users.')}
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-white/5 border border-white/5 space-y-4">
            <h3 className="text-sm font-bold text-white">Submit a Report</h3>
            <select className="w-full bg-black/20 border border-white/10 rounded-xl p-3 text-sm text-white focus:outline-none">
              <option value="bug">App Bug / Technical Issue</option>
              <option value="user">Report a User</option>
              <option value="content">Report Content</option>
              <option value="other">Other</option>
            </select>
            <textarea 
              placeholder="Describe the issue in detail..." 
              className="w-full bg-black/20 border border-white/10 rounded-xl p-3 text-sm text-white focus:outline-none min-h-[120px]"
            />
            <div className="border-2 border-dashed border-white/10 rounded-xl p-6 flex flex-col items-center justify-center gap-2 cursor-pointer hover:bg-white/5 transition-colors">
              <Upload className="w-6 h-6 text-zinc-500" />
              <p className="text-xs text-zinc-400">Upload screenshot (optional)</p>
            </div>
            <button className="w-full py-3 bg-indigo-500 rounded-xl text-white font-bold hover:bg-indigo-600 transition-colors">Submit Report</button>
          </div>
        </div>
      </div>
    );
  }

  if (activeSubView === 'guidelines') {
    return (
      <div className="max-w-2xl mx-auto p-4 space-y-6">
        {renderHeader('Community Guidelines', 'Rules and policies tailored for your region.')}
        <div className="p-6 rounded-3xl bg-white/5 border border-white/5 space-y-4">
          <div className="flex items-center gap-2 mb-4">
            <Globe className="w-5 h-5 text-indigo-400" />
            <span className="text-sm font-bold text-white">Region: Middle East (MENA)</span>
          </div>
          <div className="space-y-4 text-sm text-zinc-300 leading-relaxed">
            <p>1. Respect local laws and cultural sensitivities. Content that violates regional regulations will be removed.</p>
            <p>2. No hate speech, bullying, or harassment. We maintain a zero-tolerance policy for abusive behavior.</p>
            <p>3. Protect your privacy and the privacy of others. Do not share personal information without consent.</p>
            <p>4. Intellectual property rights must be respected. Only post content you have the right to share.</p>
          </div>
          <div className="pt-4 border-t border-white/10 mt-6">
            <p className="text-xs text-zinc-500">These guidelines are subject to change based on local government regulations and platform policy updates.</p>
          </div>
        </div>
      </div>
    );
  }

  if (activeSubView === 'archive' || activeSubView === 'saved') {
    return (
      <div className="max-w-2xl mx-auto p-4 space-y-6">
        {renderHeader(activeSubView === 'archive' ? 'Archive' : 'Saved Items', 'View your private collections.')}
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mb-4">
            {activeSubView === 'archive' ? <Archive className="w-8 h-8 text-zinc-500" /> : <Bookmark className="w-8 h-8 text-zinc-500" />}
          </div>
          <h3 className="text-lg font-bold text-white mb-2">Nothing here yet</h3>
          <p className="text-sm text-zinc-500 max-w-xs">
            {activeSubView === 'archive' ? 'Posts and stories you archive will appear here.' : 'Items you save will be collected here for easy access.'}
          </p>
        </div>
      </div>
    );
  }

  if (activeSubView === 'language') {
    return (
      <div className="max-w-2xl mx-auto p-4 space-y-8">
        {renderHeader('Language Settings', 'Choose the language that best fits your experience.')}
        <div className="grid grid-cols-1 gap-2">
          {languages.map((l) => (
            <button 
              key={l.code} 
              onClick={() => setLang(l.code as Language)}
              className="w-full flex items-center justify-between p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-indigo-500/50 transition-all group"
            >
              <div className="flex items-center gap-4">
                <span className="text-2xl">{l.flag}</span>
                <span className="text-sm font-medium text-white">{l.name}</span>
              </div>
              {lang === l.code && <Check className="w-5 h-5 text-indigo-500" />}
            </button>
          ))}
        </div>
      </div>
    );
  }

  if (activeSubView === 'safety') {
    return (
      <div className="max-w-2xl mx-auto p-4 space-y-8">
        {renderHeader('Social Safety & Controls', 'Manage how you interact with others and maintain your digital peace.')}

        <section className="space-y-4">
          <h3 className="text-sm font-bold text-zinc-400 uppercase tracking-wider">Account Restrictions</h3>
          <div className="space-y-2">
            {[
              { id: 'blocked', label: 'Blocked Accounts', icon: <Ban className="w-5 h-5" />, count: '12', color: 'text-red-400' },
              { id: 'restricted', label: 'Restricted Accounts', icon: <Shield className="w-5 h-5" />, count: '3', color: 'text-amber-400' },
              { id: 'muted', label: 'Muted Accounts', icon: <VolumeX className="w-5 h-5" />, count: '45', color: 'text-zinc-400' },
            ].map((item) => (
              <button key={item.id} className="w-full flex items-center justify-between p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-white/10 transition-all group">
                <div className="flex items-center gap-4">
                  <div className={`p-2 rounded-xl bg-zinc-900 ${item.color}`}>
                    {item.icon}
                  </div>
                  <span className="text-sm font-medium text-white">{item.label}</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-xs text-zinc-500">{item.count} accounts</span>
                  <ChevronRight className="w-4 h-4 text-zinc-600 group-hover:text-zinc-400 transition-colors" />
                </div>
              </button>
            ))}
          </div>
        </section>

        <section className="space-y-4">
          <h3 className="text-sm font-bold text-zinc-400 uppercase tracking-wider">Interactions</h3>
          <div className="space-y-2">
            <div className="p-4 rounded-2xl bg-white/5 border border-white/5 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="p-2 rounded-xl bg-zinc-900 text-indigo-400">
                    <MessageSquareOff className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white">Comment Approval</p>
                    <p className="text-xs text-zinc-500">Review comments before they go public</p>
                  </div>
                </div>
                <div className="relative w-12 h-6 bg-indigo-500 rounded-full">
                  <div className="absolute top-1 right-1 w-4 h-4 bg-white rounded-full shadow-lg" />
                </div>
              </div>
              <div className="pt-4 border-t border-white/5">
                <div className="flex items-center gap-4">
                  <div className="p-2 rounded-xl bg-zinc-900 text-emerald-400">
                    <Filter className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-white">Keyword Filter</p>
                    <p className="text-xs text-zinc-500">Automatically hide comments with specific words</p>
                  </div>
                  <button className="text-xs font-bold text-indigo-400 hover:text-indigo-300">Manage</button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto p-4 space-y-8">
      <header className="space-y-2">
        <h2 className="text-2xl font-bold text-white">Settings</h2>
        <p className="text-zinc-500 text-sm">Manage your account preferences and application settings.</p>
      </header>

      {/* Theme Toggle Quick Action */}
      <div className="p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="p-2 bg-indigo-500 rounded-xl">
            <Moon className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="text-sm font-bold text-white">{theme === 'dark' ? 'Dark Mode' : 'Light Mode'}</p>
            <p className="text-xs text-indigo-400/70">{theme === 'dark' ? 'Easier on the eyes' : 'Bright and clear'}</p>
          </div>
        </div>
        <button
          onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
          className={`relative w-12 h-6 rounded-full transition-all duration-300 ${theme === 'dark' ? 'bg-indigo-500' : 'bg-zinc-400'}`}
        >
          <motion.div
            animate={{ x: theme === 'dark' ? 24 : 2 }}
            className="absolute top-1 w-4 h-4 bg-white rounded-full shadow-lg"
          />
        </button>
      </div>

      {sections.map((section) => (
        <section key={section.title} className="space-y-4">
          <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-wider px-2">{section.title}</h3>
          <div className="space-y-2">
            {section.items.map((item: any) => (
              <button
                key={item.id}
                onClick={item.action}
                className="w-full flex items-center justify-between p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-white/10 hover:bg-white/[0.07] transition-all group text-left"
              >
                <div className="flex items-center gap-4">
                  <div className="p-2 rounded-xl bg-zinc-900 text-zinc-400 group-hover:text-indigo-400 transition-colors">
                    {item.icon}
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white">{item.label}</p>
                    <p className="text-xs text-zinc-500">{item.desc}</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-zinc-600 group-hover:text-zinc-400 transition-colors" />
              </button>
            ))}
          </div>
        </section>
      ))}

      <div className="pt-6 border-t border-white/5 space-y-2">
        <button className="w-full flex items-center gap-4 p-4 rounded-2xl bg-white/5 border border-white/5 hover:bg-red-500/10 hover:border-red-500/20 transition-all group text-left">
          <div className="p-2 rounded-xl bg-zinc-900 text-zinc-400 group-hover:text-red-400 transition-colors">
            <HelpCircle className="w-5 h-5" />
          </div>
          <span className="text-sm font-medium text-white group-hover:text-red-400 transition-colors">Support & Help</span>
        </button>
        <button className="w-full flex items-center gap-4 p-4 rounded-2xl bg-red-500/10 border border-red-500/20 hover:bg-red-500/20 transition-all group text-left">
          <div className="p-2 rounded-xl bg-red-500/20 text-red-400">
            <LogOut className="w-5 h-5" />
          </div>
          <span className="text-sm font-bold text-red-400">Logout Session</span>
        </button>
      </div>
    </div>
  );
}
