'use client';

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Shield, 
  Ban, 
  VolumeX, 
  MessageSquareOff, 
  Filter, 
  AlertTriangle,
  ChevronRight,
  UserX,
  EyeOff,
  BellOff,
  Lock
} from 'lucide-react';

export default function SocialControls() {
  return (
    <div className="max-w-2xl mx-auto p-4 space-y-8">
      <header className="space-y-2">
        <h2 className="text-2xl font-bold text-white">Social Safety & Controls</h2>
        <p className="text-zinc-500 text-sm">Manage how you interact with others and maintain your digital peace.</p>
      </header>

      {/* Account Restrictions */}
      <section className="space-y-4">
        <h3 className="text-sm font-bold text-zinc-400 uppercase tracking-wider">Account Restrictions</h3>
        <div className="space-y-2">
          {[
            { id: 'blocked', label: 'Blocked Accounts', icon: <Ban className="w-5 h-5" />, count: '12', color: 'text-red-400' },
            { id: 'restricted', label: 'Restricted Accounts', icon: <Shield className="w-5 h-5" />, count: '3', color: 'text-amber-400' },
            { id: 'muted', label: 'Muted Accounts', icon: <VolumeX className="w-5 h-5" />, count: '45', color: 'text-zinc-400' },
          ].map((item) => (
            <button key={item.id} className="w-full flex items-center justify-between p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-white/10 transition-all group">
              <div className="flex items-center gap-4">
                <div className={`p-2 rounded-xl bg-zinc-900 ${item.color}`}>
                  {item.icon}
                </div>
                <span className="text-sm font-medium text-white">{item.label}</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs text-zinc-500">{item.count} accounts</span>
                <ChevronRight className="w-4 h-4 text-zinc-600 group-hover:text-zinc-400 transition-colors" />
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* Interactions */}
      <section className="space-y-4">
        <h3 className="text-sm font-bold text-zinc-400 uppercase tracking-wider">Interactions</h3>
        <div className="space-y-2">
          <div className="p-4 rounded-2xl bg-white/5 border border-white/5 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="p-2 rounded-xl bg-zinc-900 text-indigo-400">
                  <MessageSquareOff className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-sm font-medium text-white">Comment Approval</p>
                  <p className="text-xs text-zinc-500">Review comments before they go public</p>
                </div>
              </div>
              <div className="relative w-12 h-6 bg-indigo-500 rounded-full">
                <div className="absolute top-1 right-1 w-4 h-4 bg-white rounded-full shadow-lg" />
              </div>
            </div>
            <div className="pt-4 border-t border-white/5">
              <div className="flex items-center gap-4">
                <div className="p-2 rounded-xl bg-zinc-900 text-emerald-400">
                  <Filter className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-white">Keyword Filter</p>
                  <p className="text-xs text-zinc-500">Automatically hide comments with specific words</p>
                </div>
                <button className="text-xs font-bold text-indigo-400 hover:text-indigo-300">Manage</button>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-white/5 border border-white/5 flex items-center justify-between group cursor-pointer hover:bg-white/[0.07] transition-all">
            <div className="flex items-center gap-4">
              <div className="p-2 rounded-xl bg-zinc-900 text-amber-400">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm font-medium text-white">Limit Account Interactions</p>
                <p className="text-xs text-zinc-500">Temporarily limit comments and messages</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-zinc-600 group-hover:text-zinc-400 transition-colors" />
          </div>
        </div>
      </section>

      {/* Anti-Spam */}
      <section className="p-6 rounded-3xl bg-gradient-to-br from-indigo-500/10 to-purple-500/10 border border-indigo-500/20 relative overflow-hidden">
        <div className="absolute -top-12 -right-12 w-32 h-32 bg-indigo-500/10 blur-[60px] rounded-full" />
        <div className="relative z-10 space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-500 rounded-xl shadow-[0_0_20px_rgba(79,70,229,0.4)]">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <h4 className="text-lg font-bold text-white">Anti-Spam AI Protection</h4>
          </div>
          <p className="text-zinc-400 text-sm leading-relaxed">
            Our advanced AI automatically detects and filters spam, bots, and malicious links to keep your profile clean and secure.
          </p>
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
            Active & Protecting
          </div>
        </div>
      </section>
    </div>
  );
}
