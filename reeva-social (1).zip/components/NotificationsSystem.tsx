'use client';

import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Image from 'next/image';
import { 
  Heart, 
  MessageCircle, 
  UserPlus, 
  Star, 
  Zap, 
  Bell,
  Settings,
  ChevronRight
} from 'lucide-react';

interface Notification {
  id: string;
  type: 'like' | 'comment' | 'follow' | 'mention' | 'system';
  user?: {
    name: string;
    avatar: string;
  };
  content: string;
  time: string;
  isUnread: boolean;
  media?: string;
}

const MOCK_NOTIFICATIONS: Notification[] = [
  { id: '1', type: 'like', user: { name: 'Sarah Chen', avatar: 'https://picsum.photos/seed/2/100' }, content: 'liked your post', time: '2m ago', isUnread: true, media: 'https://picsum.photos/seed/art/100' },
  { id: '2', type: 'follow', user: { name: 'Marcus Thorne', avatar: 'https://picsum.photos/seed/3/100' }, content: 'started following you', time: '15m ago', isUnread: true },
  { id: '3', type: 'comment', user: { name: 'Alex Rivera', avatar: 'https://picsum.photos/seed/1/100' }, content: 'commented: "This is pure fire! 🔥"', time: '1h ago', isUnread: false, media: 'https://picsum.photos/seed/art/100' },
  { id: '4', type: 'system', content: 'Your account security has been updated.', time: '3h ago', isUnread: false },
  { id: '5', type: 'mention', user: { name: 'Elena Vance', avatar: 'https://picsum.photos/seed/4/100' }, content: 'mentioned you in a story', time: '5h ago', isUnread: false },
];

interface NotificationsSystemProps {
  onOpenSettings?: () => void;
  onGoToPost?: (postId: string) => void;
}

export default function NotificationsSystem({ onOpenSettings, onGoToPost }: NotificationsSystemProps) {
  const hapticProps = {
    whileTap: { scale: 0.98 },
    transition: { type: "spring" as const, stiffness: 400, damping: 17 }
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'like': return <Heart className="w-4 h-4 text-rose-500 fill-current" />;
      case 'comment': return <MessageCircle className="w-4 h-4 text-indigo-400" />;
      case 'follow': return <UserPlus className="w-4 h-4 text-emerald-400" />;
      case 'mention': return <Star className="w-4 h-4 text-amber-400 fill-current" />;
      default: return <Zap className="w-4 h-4 text-indigo-400" />;
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <header className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black text-white">Notifications</h2>
          <p className="text-xs text-zinc-500 font-medium uppercase tracking-widest">Stay updated with your circle</p>
        </div>
        <motion.button 
          {...hapticProps} 
          onClick={onOpenSettings}
          className="p-3 bg-white/5 hover:bg-white/10 rounded-2xl text-zinc-400 transition-all"
        >
          <Settings className="w-5 h-5" />
        </motion.button>
      </header>

      <div className="space-y-3">
        <AnimatePresence mode="popLayout">
          {MOCK_NOTIFICATIONS.map((notif) => (
            <motion.div
              key={notif.id}
              layout
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              onClick={() => onGoToPost?.(notif.id)}
              className={`group flex items-center justify-between p-4 rounded-3xl border transition-all cursor-pointer
                ${notif.isUnread 
                  ? 'bg-indigo-500/5 border-indigo-500/20 shadow-[0_0_20px_rgba(79,70,229,0.05)]' 
                  : 'bg-white/5 border-white/5 hover:border-white/10'}`}
            >
              <div className="flex items-center gap-4 flex-1">
                <div className="relative">
                  {notif.user ? (
                    <div className="w-12 h-12 rounded-full relative overflow-hidden border border-white/10">
                      <Image src={notif.user.avatar} alt={notif.user.name} fill className="object-cover" referrerPolicy="no-referrer" />
                    </div>
                  ) : (
                    <div className="w-12 h-12 rounded-full bg-indigo-500/20 flex items-center justify-center">
                      <Bell className="w-6 h-6 text-indigo-400" />
                    </div>
                  )}
                  <div className="absolute -bottom-1 -right-1 p-1.5 bg-zinc-950 rounded-full border border-white/10">
                    {getIcon(notif.type)}
                  </div>
                </div>
                
                <div className="flex-1">
                  <p className="text-sm text-zinc-300">
                    {notif.user && <span className="font-bold text-white mr-1">{notif.user.name}</span>}
                    {notif.content}
                  </p>
                  <p className="text-[10px] text-zinc-500 font-medium mt-1 uppercase tracking-wider">{notif.time}</p>
                </div>
              </div>

              {notif.media && (
                <div className="w-12 h-12 rounded-xl relative overflow-hidden border border-white/10 ml-4">
                  <Image src={notif.media} alt="media" fill className="object-cover" referrerPolicy="no-referrer" />
                </div>
              )}
              
              {!notif.media && (
                <ChevronRight className="w-4 h-4 text-zinc-700 group-hover:text-zinc-400 transition-colors ml-4" />
              )}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <div className="flex justify-center">
        <button className="text-xs font-bold text-zinc-500 hover:text-white transition-colors uppercase tracking-widest">
          View all activity
        </button>
      </div>
    </div>
  );
}
