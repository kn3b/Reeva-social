'use client';

import React from 'react';
import { motion } from 'motion/react';
import Image from 'next/image';
import { Search, TrendingUp, Hash, Play, Heart, MessageCircle, Sparkles } from 'lucide-react';

const MOCK_EXPLORE = Array.from({ length: 15 }).map((_, i) => ({
  id: i,
  type: i % 4 === 0 ? 'reel' : 'image',
  url: `https://picsum.photos/seed/explore${i}/${i % 4 === 0 ? '400/600' : '400/400'}`,
  likes: Math.floor(Math.random() * 10000),
  comments: Math.floor(Math.random() * 1000)
}));

export default function ExploreSystem() {
  return (
    <div className="max-w-7xl mx-auto space-y-8">
      {/* Search & Trending Header */}
      <div className="flex flex-col gap-6 bg-zinc-900/50 backdrop-blur-xl p-6 rounded-[32px] border border-white/5">
        <div className="flex flex-col md:flex-row gap-6 items-start md:items-center justify-between">
          <div className="w-full md:w-1/2 relative group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-500 group-focus-within:text-indigo-400 transition-colors" />
            <input 
              type="text" 
              placeholder="Search for creators, trends, or topics..." 
              className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-indigo-500/50 transition-all"
            />
          </div>
          
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 text-zinc-400 mr-2">
              <TrendingUp className="w-5 h-5 text-rose-500" />
              <span className="text-sm font-bold uppercase tracking-wider">Trending:</span>
            </div>
            {['#AIArt', '#Cyberpunk', '#DubaiLife', '#Tech2026'].map(tag => (
              <button key={tag} className="px-4 py-2 bg-white/5 hover:bg-indigo-500/20 hover:text-indigo-400 border border-white/5 rounded-xl text-sm font-medium text-zinc-300 transition-all">
                {tag}
              </button>
            ))}
          </div>
        </div>

        {/* Algorithm Note */}
        <div className="flex items-start gap-3 bg-indigo-500/10 border border-indigo-500/20 rounded-2xl p-4">
          <Sparkles className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-bold text-indigo-300 mb-1">Curated for You</p>
            <p className="text-xs text-zinc-400 leading-relaxed">
              Our algorithm prioritizes freedom of speech, premium content, and comedy based on your unique interests. We believe in showing you what matters most to you, without unnecessary filtering.
            </p>
          </div>
        </div>
      </div>

      {/* Masonry Grid */}
      <div className="columns-2 md:columns-3 lg:columns-4 gap-4 space-y-4">
        {MOCK_EXPLORE.map((item) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: item.id * 0.05 }}
            className="relative group cursor-pointer rounded-2xl overflow-hidden break-inside-avoid bg-zinc-900 border border-white/5"
          >
            <Image 
              src={item.url} 
              alt="Explore content" 
              width={400}
              height={item.type === 'reel' ? 600 : 400}
              className="w-full object-cover group-hover:scale-110 transition-transform duration-700"
              referrerPolicy="no-referrer"
            />
            
            {/* Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-4">
              {item.type === 'reel' && (
                <div className="absolute top-4 right-4 p-2 bg-black/50 backdrop-blur-md rounded-full">
                  <Play className="w-4 h-4 text-white fill-current" />
                </div>
              )}
              <div className="flex items-center gap-4 text-white font-bold">
                <span className="flex items-center gap-1.5"><Heart className="w-4 h-4 fill-current text-rose-500" /> {item.likes}</span>
                <span className="flex items-center gap-1.5"><MessageCircle className="w-4 h-4 fill-current" /> {item.comments}</span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
