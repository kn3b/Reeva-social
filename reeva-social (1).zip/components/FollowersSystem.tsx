'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  UserMinus, 
  UserPlus, 
  Bell, 
  BellOff, 
  Star, 
  MoreVertical,
  Shield,
  EyeOff,
  Check
} from 'lucide-react';

interface User {
  id: string;
  name: string;
  username: string;
  avatar: string;
  isOnline: boolean;
  isMutual: boolean;
  isFollowing: boolean;
  isFavorite: boolean;
  notifications: boolean;
}

const MOCK_USERS: User[] = [
  { id: '1', name: 'Alex Rivera', username: 'arivera', avatar: 'https://picsum.photos/seed/1/100', isOnline: true, isMutual: true, isFollowing: true, isFavorite: true, notifications: true },
  { id: '2', name: 'Sarah Chen', username: 'schen_art', avatar: 'https://picsum.photos/seed/2/100', isOnline: false, isMutual: true, isFollowing: true, isFavorite: false, notifications: false },
  { id: '3', name: 'Marcus Thorne', username: 'mthorne', avatar: 'https://picsum.photos/seed/3/100', isOnline: true, isMutual: false, isFollowing: false, isFavorite: false, notifications: false },
  { id: '4', name: 'Elena Vance', username: 'evance', avatar: 'https://picsum.photos/seed/4/100', isOnline: true, isMutual: true, isFollowing: true, isFavorite: true, notifications: true },
  { id: '5', name: 'Julian Black', username: 'jblack_dev', avatar: 'https://picsum.photos/seed/5/100', isOnline: false, isMutual: false, isFollowing: true, isFavorite: false, notifications: true },
];

export default function FollowersSystem() {
  const [activeTab, setActiveTab] = useState<'followers' | 'following'>('followers');
  const [searchQuery, setSearchQuery] = useState('');
  const [users, setUsers] = useState<User[]>(MOCK_USERS);

  const filteredUsers = users.filter(u => 
    u.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    u.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleFollow = (id: string) => {
    setUsers(users.map(u => u.id === id ? { ...u, isFollowing: !u.isFollowing } : u));
  };

  const toggleNotifications = (id: string) => {
    setUsers(users.map(u => u.id === id ? { ...u, notifications: !u.notifications } : u));
  };

  return (
    <div className="max-w-2xl mx-auto p-4 space-y-6">
      {/* Tabs */}
      <div className="flex p-1 bg-zinc-900 rounded-2xl border border-white/5">
        <button
          onClick={() => setActiveTab('followers')}
          className={`flex-1 py-3 rounded-xl text-sm font-medium transition-all relative
            ${activeTab === 'followers' ? 'text-white' : 'text-zinc-500 hover:text-zinc-300'}`}
        >
          {activeTab === 'followers' && (
            <motion.div layoutId="tab-bg" className="absolute inset-0 bg-white/5 rounded-xl border border-white/10 shadow-lg" />
          )}
          <span className="relative z-10">Followers (1.2k)</span>
        </button>
        <button
          onClick={() => setActiveTab('following')}
          className={`flex-1 py-3 rounded-xl text-sm font-medium transition-all relative
            ${activeTab === 'following' ? 'text-white' : 'text-zinc-500 hover:text-zinc-300'}`}
        >
          {activeTab === 'following' && (
            <motion.div layoutId="tab-bg" className="absolute inset-0 bg-white/5 rounded-xl border border-white/10 shadow-lg" />
          )}
          <span className="relative z-10">Following (842)</span>
        </button>
      </div>

      {/* Search */}
      <div className="relative group">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-500 group-focus-within:text-indigo-400 transition-colors" />
        <input
          type="text"
          placeholder={`Search ${activeTab}...`}
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full bg-zinc-900 border border-white/5 rounded-2xl py-4 pl-12 pr-4 text-white placeholder-zinc-500 focus:outline-none focus:border-indigo-500/50 transition-all"
        />
      </div>

      {/* User List */}
      <div className="space-y-2">
        <AnimatePresence mode="popLayout">
          {filteredUsers.map((user) => (
            <motion.div
              key={user.id}
              layout
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="group flex items-center justify-between p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-white/10 hover:bg-white/[0.07] transition-all"
            >
              <div className="flex items-center gap-4">
                <div className="relative w-12 h-12">
                  <Image 
                    src={user.avatar} 
                    alt={user.name} 
                    fill 
                    className="rounded-full object-cover border border-white/10"
                    referrerPolicy="no-referrer"
                  />
                  {user.isOnline && (
                    <div className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-500 border-2 border-zinc-950 rounded-full shadow-[0_0_10px_rgba(16,185,129,0.5)] z-10" />
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-semibold text-white">{user.name}</p>
                    {user.isMutual && (
                      <span className="text-[10px] px-1.5 py-0.5 bg-zinc-800 text-zinc-400 rounded-md font-medium">Mutual</span>
                    )}
                  </div>
                  <p className="text-xs text-zinc-500">@{user.username}</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {activeTab === 'following' && (
                  <button
                    onClick={() => toggleNotifications(user.id)}
                    className={`p-2 rounded-xl transition-all ${user.notifications ? 'text-indigo-400 bg-indigo-400/10' : 'text-zinc-500 hover:bg-white/5'}`}
                  >
                    {user.notifications ? <Bell className="w-4 h-4" /> : <BellOff className="w-4 h-4" />}
                  </button>
                )}
                
                <button
                  onClick={() => toggleFollow(user.id)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2
                    ${user.isFollowing 
                      ? 'bg-zinc-800 text-white hover:bg-zinc-700' 
                      : 'bg-indigo-500 text-white hover:bg-indigo-600 shadow-[0_0_15px_rgba(79,70,229,0.3)]'}`}
                >
                  {user.isFollowing ? (
                    <>
                      <Check className="w-3 h-3" />
                      Following
                    </>
                  ) : (
                    <>
                      <UserPlus className="w-3 h-3" />
                      Follow Back
                    </>
                  )}
                </button>

                <button className="p-2 text-zinc-500 hover:text-white hover:bg-white/5 rounded-xl transition-all">
                  <MoreVertical className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Privacy Settings Footer */}
      <div className="pt-6 border-t border-white/5">
        <div className="bg-indigo-500/5 rounded-2xl p-6 border border-indigo-500/10 space-y-4">
          <div className="flex items-center gap-3">
            <Shield className="w-5 h-5 text-indigo-400" />
            <h4 className="text-sm font-semibold text-white">Social Privacy</h4>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button className="flex items-center justify-between p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-all group">
              <span className="text-xs text-zinc-400 group-hover:text-white">Hide Followers List</span>
              <EyeOff className="w-3 h-3 text-zinc-500" />
            </button>
            <button className="flex items-center justify-between p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-all group">
              <span className="text-xs text-zinc-400 group-hover:text-white">Hide Following List</span>
              <EyeOff className="w-3 h-3 text-zinc-500" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
