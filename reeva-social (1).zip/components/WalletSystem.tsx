'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Wallet, ArrowUpRight, ArrowDownRight, DollarSign, CreditCard, Clock, Star, Zap, Globe, BarChart3, Users, MapPin, PieChart, ChevronRight, Building2, ShieldCheck, Activity } from 'lucide-react';

export default function WalletSystem() {
  const [activeTab, setActiveTab] = useState<'wallet' | 'analytics'>('wallet');

  const hapticProps = {
    whileTap: { scale: 0.95 },
    transition: { type: "spring" as const, stiffness: 400, damping: 17 }
  };

  const transactions = [
    { id: 1, type: 'income', title: 'Live Stream Gifts', amount: '+$450.00', date: 'Today, 2:30 PM', status: 'completed' },
    { id: 2, type: 'income', title: 'Premium Subscription', amount: '+$12.99', date: 'Yesterday', status: 'completed' },
    { id: 3, type: 'expense', title: 'Withdrawal to Bank', amount: '-$1,200.00', date: 'Oct 12, 2026', status: 'processing' },
    { id: 4, type: 'income', title: 'Reels Bonus Program', amount: '+$850.00', date: 'Oct 10, 2026', status: 'completed' },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-20">
      <header className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black text-white">Professional Dashboard</h2>
          <p className="text-xs text-zinc-500 font-medium uppercase tracking-widest">Manage your monetization & analytics</p>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="flex bg-zinc-900/50 p-1.5 rounded-2xl border border-white/5 w-fit">
        <button 
          onClick={() => setActiveTab('wallet')}
          className={`px-6 py-2.5 rounded-xl text-sm font-bold transition-all ${activeTab === 'wallet' ? 'bg-indigo-500 text-white shadow-lg' : 'text-zinc-400 hover:text-white'}`}
        >
          Wallet & Earnings
        </button>
        <button 
          onClick={() => setActiveTab('analytics')}
          className={`px-6 py-2.5 rounded-xl text-sm font-bold transition-all ${activeTab === 'analytics' ? 'bg-indigo-500 text-white shadow-lg' : 'text-zinc-400 hover:text-white'}`}
        >
          Analytics & Insights
        </button>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'wallet' ? (
          <motion.div 
            key="wallet"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-8"
          >
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Main Balance Card */}
              <div className="md:col-span-2 bg-gradient-to-br from-[#5254FF] to-[#7172FA] rounded-[32px] p-8 relative overflow-hidden shadow-[0_0_40px_rgba(82,84,255,0.3)]">
                <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/4" />
                
                <div className="relative z-10 flex flex-col h-full justify-between">
                  <div className="flex items-center justify-between mb-8">
                    <div className="flex items-center gap-2 bg-white/20 backdrop-blur-md px-4 py-2 rounded-full">
                      <Wallet className="w-4 h-4 text-white" />
                      <span className="text-sm font-bold text-white">Available Balance</span>
                    </div>
                    <CreditCard className="w-8 h-8 text-white/50" />
                  </div>
                  
                  <div>
                    <h1 className="text-5xl md:text-7xl font-black text-white tracking-tighter mb-2">$12,450.00</h1>
                    <p className="text-white/80 font-medium flex items-center gap-2">
                      <ArrowUpRight className="w-4 h-4 text-emerald-300" />
                      +$1,240.50 this month
                    </p>
                  </div>

                  <div className="flex gap-4 mt-8">
                    <motion.button {...hapticProps} className="px-6 py-3 bg-white text-indigo-600 rounded-xl font-bold shadow-lg">
                      Withdraw Funds
                    </motion.button>
                  </div>
                </div>
              </div>

              {/* Quick Stats */}
              <div className="space-y-6">
                <div className="bg-zinc-900/50 backdrop-blur-xl border border-white/5 rounded-[32px] p-6">
                  <div className="w-12 h-12 bg-amber-500/20 rounded-2xl flex items-center justify-center mb-4">
                    <Star className="w-6 h-6 text-amber-500" />
                  </div>
                  <p className="text-sm text-zinc-400 font-medium mb-1">Active Subscribers</p>
                  <h3 className="text-3xl font-black text-white">1,204</h3>
                </div>
                <div className="bg-zinc-900/50 backdrop-blur-xl border border-white/5 rounded-[32px] p-6">
                  <div className="w-12 h-12 bg-rose-500/20 rounded-2xl flex items-center justify-center mb-4">
                    <Zap className="w-6 h-6 text-rose-500" />
                  </div>
                  <p className="text-sm text-zinc-400 font-medium mb-1">Live Gifts Value</p>
                  <h3 className="text-3xl font-black text-white">$845.50</h3>
                </div>
              </div>
            </div>

            {/* Linked Accounts */}
            <div className="bg-zinc-900/50 backdrop-blur-xl border border-white/5 rounded-[32px] p-6 md:p-8">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-lg font-bold text-white">Linked Global Banks</h3>
                  <p className="text-xs text-zinc-500 mt-1">Manage your withdrawal methods</p>
                </div>
                <button className="px-4 py-2 bg-white/5 hover:bg-white/10 rounded-xl text-sm font-bold text-white transition-colors flex items-center gap-2">
                  <Globe className="w-4 h-4" /> Add Bank
                </button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-indigo-500/20 rounded-xl flex items-center justify-center">
                      <Building2 className="w-6 h-6 text-indigo-400" />
                    </div>
                    <div>
                      <p className="font-bold text-white">Chase Bank</p>
                      <p className="text-xs text-zinc-400">**** 4582</p>
                    </div>
                  </div>
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                </div>
                <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-rose-500/20 rounded-xl flex items-center justify-center">
                      <Globe className="w-6 h-6 text-rose-400" />
                    </div>
                    <div>
                      <p className="font-bold text-white">Wise (International)</p>
                      <p className="text-xs text-zinc-400">EUR Account</p>
                    </div>
                  </div>
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                </div>
              </div>
            </div>

            {/* Transactions */}
            <div className="bg-zinc-900/50 backdrop-blur-xl border border-white/5 rounded-[32px] p-6 md:p-8">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold text-white">Recent Transactions</h3>
                <button className="text-sm font-bold text-indigo-400 hover:text-indigo-300">View All</button>
              </div>
              
              <div className="space-y-4">
                {transactions.map((tx) => (
                  <div key={tx.id} className="flex items-center justify-between p-4 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition-colors">
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center
                        ${tx.type === 'income' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-zinc-800 text-zinc-400'}`}>
                        {tx.type === 'income' ? <ArrowDownRight className="w-6 h-6" /> : <ArrowUpRight className="w-6 h-6" />}
                      </div>
                      <div>
                        <p className="text-sm font-bold text-white">{tx.title}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Clock className="w-3 h-3 text-zinc-500" />
                          <p className="text-[10px] text-zinc-500 font-medium">{tx.date}</p>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`text-sm font-black ${tx.type === 'income' ? 'text-emerald-400' : 'text-white'}`}>
                        {tx.amount}
                      </p>
                      <p className={`text-[10px] font-bold uppercase tracking-wider mt-1
                        ${tx.status === 'completed' ? 'text-zinc-500' : 'text-amber-400'}`}>
                        {tx.status}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        ) : (
          <motion.div 
            key="analytics"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-8"
          >
            {/* Analytics Overview */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: 'Total Reach', value: '2.4M', icon: <Users className="w-5 h-5 text-indigo-400" />, trend: '+12%' },
                { label: 'Engagement Rate', value: '8.5%', icon: <Activity className="w-5 h-5 text-emerald-400" />, trend: '+2.1%' },
                { label: 'Profile Visits', value: '145K', icon: <Star className="w-5 h-5 text-amber-400" />, trend: '+5%' },
                { label: 'Content Shares', value: '32K', icon: <ArrowUpRight className="w-5 h-5 text-rose-400" />, trend: '+18%' },
              ].map((stat, i) => (
                <div key={i} className="bg-zinc-900/50 backdrop-blur-xl border border-white/5 rounded-[24px] p-5">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-2 bg-white/5 rounded-xl">{stat.icon}</div>
                    <span className="text-xs font-bold text-emerald-400 bg-emerald-400/10 px-2 py-1 rounded-full">{stat.trend}</span>
                  </div>
                  <h4 className="text-2xl font-black text-white mb-1">{stat.value}</h4>
                  <p className="text-xs text-zinc-400 font-medium">{stat.label}</p>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Demographics */}
              <div className="bg-zinc-900/50 backdrop-blur-xl border border-white/5 rounded-[32px] p-6 md:p-8">
                <div className="flex items-center gap-3 mb-8">
                  <div className="p-3 bg-indigo-500/20 rounded-xl"><PieChart className="w-6 h-6 text-indigo-400" /></div>
                  <div>
                    <h3 className="text-lg font-bold text-white">Audience Demographics</h3>
                    <p className="text-xs text-zinc-500">Age & Gender distribution</p>
                  </div>
                </div>
                
                <div className="space-y-6">
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-zinc-400">18-24</span>
                      <span className="text-white font-bold">45%</span>
                    </div>
                    <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                      <div className="h-full bg-indigo-500 w-[45%]" />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-zinc-400">25-34</span>
                      <span className="text-white font-bold">35%</span>
                    </div>
                    <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                      <div className="h-full bg-indigo-400 w-[35%]" />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-zinc-400">35-44</span>
                      <span className="text-white font-bold">15%</span>
                    </div>
                    <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                      <div className="h-full bg-indigo-300 w-[15%]" />
                    </div>
                  </div>
                </div>
              </div>

              {/* Top Locations */}
              <div className="bg-zinc-900/50 backdrop-blur-xl border border-white/5 rounded-[32px] p-6 md:p-8">
                <div className="flex items-center gap-3 mb-8">
                  <div className="p-3 bg-rose-500/20 rounded-xl"><MapPin className="w-6 h-6 text-rose-400" /></div>
                  <div>
                    <h3 className="text-lg font-bold text-white">Top Locations</h3>
                    <p className="text-xs text-zinc-500">Where your audience lives</p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  {[
                    { country: 'United States', percentage: '32%' },
                    { country: 'United Kingdom', percentage: '18%' },
                    { country: 'United Arab Emirates', percentage: '12%' },
                    { country: 'Germany', percentage: '8%' },
                  ].map((loc, i) => (
                    <div key={i} className="flex items-center justify-between p-3 rounded-xl bg-white/5">
                      <span className="text-sm font-medium text-zinc-300">{loc.country}</span>
                      <span className="text-sm font-bold text-white">{loc.percentage}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Top Performing Content */}
            <div className="bg-zinc-900/50 backdrop-blur-xl border border-white/5 rounded-[32px] p-6 md:p-8">
              <div className="flex items-center gap-3 mb-8">
                <div className="p-3 bg-emerald-500/20 rounded-xl"><BarChart3 className="w-6 h-6 text-emerald-400" /></div>
                <div>
                  <h3 className="text-lg font-bold text-white">Top Performing Content</h3>
                  <p className="text-xs text-zinc-500">Most impactful posts this month</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="relative rounded-2xl overflow-hidden aspect-[4/5] group cursor-pointer">
                    <img src={`https://picsum.photos/seed/top${i}/400/500`} alt="Top content" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent flex flex-col justify-end p-4">
                      <div className="flex items-center justify-between text-white">
                        <div className="flex items-center gap-1">
                          <Activity className="w-4 h-4 text-emerald-400" />
                          <span className="text-sm font-bold">124K</span>
                        </div>
                        <ChevronRight className="w-5 h-5 text-white/50 group-hover:text-white transition-colors" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
