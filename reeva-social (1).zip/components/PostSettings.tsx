'use client';

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Globe, 
  Users, 
  Star, 
  Lock, 
  MessageSquare, 
  Heart, 
  Share2, 
  Scissors,
  Calendar,
  FileText,
  History,
  ExternalLink
} from 'lucide-react';

interface ToggleProps {
  label: string;
  icon: React.ReactNode;
  checked: boolean;
  onChange: (val: boolean) => void;
  description?: string;
}

const GlowingToggle = ({ label, icon, checked, onChange, description }: ToggleProps) => {
  return (
    <div className="flex items-center justify-between p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-white/10 transition-all group">
      <div className="flex items-center gap-4">
        <div className={`p-2 rounded-xl transition-colors ${checked ? 'bg-indigo-500/20 text-indigo-400' : 'bg-zinc-800 text-zinc-500'}`}>
          {icon}
        </div>
        <div>
          <p className="text-sm font-medium text-white">{label}</p>
          {description && <p className="text-xs text-zinc-500">{description}</p>}
        </div>
      </div>
      <button
        onClick={() => onChange(!checked)}
        className={`relative w-12 h-6 rounded-full transition-all duration-300 ${checked ? 'bg-indigo-500 shadow-[0_0_15px_rgba(79,70,229,0.5)]' : 'bg-zinc-700'}`}
      >
        <motion.div
          animate={{ x: checked ? 24 : 2 }}
          className="absolute top-1 w-4 h-4 bg-white rounded-full shadow-lg"
          transition={{ type: "spring", stiffness: 500, damping: 30 }}
        />
      </button>
    </div>
  );
};

export default function PostSettings() {
  const [privacy, setPrivacy] = useState<'public' | 'followers' | 'friends' | 'private'>('public');
  const [allowComments, setAllowComments] = useState(true);
  const [allowLikes, setAllowLikes] = useState(true);
  const [hideLikes, setHideLikes] = useState(false);
  const [allowShares, setAllowShares] = useState(true);
  const [allowRemix, setAllowRemix] = useState(false);

  const privacyOptions = [
    { id: 'public', label: 'Public', icon: <Globe className="w-4 h-4" />, desc: 'Anyone on Reeva' },
    { id: 'followers', label: 'Followers', icon: <Users className="w-4 h-4" />, desc: 'People who follow you' },
    { id: 'friends', label: 'Close Friends', icon: <Star className="w-4 h-4" />, desc: 'Selected inner circle' },
    { id: 'private', label: 'Only Me', icon: <Lock className="w-4 h-4" />, desc: 'Private to you' },
  ];

  return (
    <div className="max-w-2xl mx-auto p-4 space-y-8">
      <section className="space-y-4">
        <h3 className="text-lg font-semibold text-white flex items-center gap-2">
          <Lock className="w-5 h-5 text-indigo-400" />
          Privacy Controls
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {privacyOptions.map((opt) => (
            <button
              key={opt.id}
              onClick={() => setPrivacy(opt.id as any)}
              className={`flex items-center gap-4 p-4 rounded-2xl border transition-all text-left
                ${privacy === opt.id 
                  ? 'bg-indigo-500/10 border-indigo-500/50 shadow-[0_0_20px_rgba(79,70,229,0.1)]' 
                  : 'bg-white/5 border-white/5 hover:border-white/10'}`}
            >
              <div className={`p-2 rounded-xl ${privacy === opt.id ? 'bg-indigo-500 text-white' : 'bg-zinc-800 text-zinc-400'}`}>
                {opt.icon}
              </div>
              <div>
                <p className="text-sm font-medium text-white">{opt.label}</p>
                <p className="text-xs text-zinc-500">{opt.desc}</p>
              </div>
            </button>
          ))}
        </div>
      </section>

      <section className="space-y-4">
        <h3 className="text-lg font-semibold text-white flex items-center gap-2">
          <MessageSquare className="w-5 h-5 text-indigo-400" />
          Engagement
        </h3>
        <div className="space-y-3">
          <GlowingToggle 
            label="Allow Comments" 
            icon={<MessageSquare className="w-4 h-4" />} 
            checked={allowComments} 
            onChange={setAllowComments} 
            description="Let people share their thoughts"
          />
          <GlowingToggle 
            label="Allow Likes" 
            icon={<Heart className="w-4 h-4" />} 
            checked={allowLikes} 
            onChange={setAllowLikes} 
          />
          <GlowingToggle 
            label="Hide Like Count" 
            icon={<Lock className="w-4 h-4" />} 
            checked={hideLikes} 
            onChange={setHideLikes} 
            description="Only you can see the total likes"
          />
          <GlowingToggle 
            label="Allow Shares" 
            icon={<Share2 className="w-4 h-4" />} 
            checked={allowShares} 
            onChange={setAllowShares} 
          />
          <GlowingToggle 
            label="Turn off Remix" 
            icon={<Scissors className="w-4 h-4" />} 
            checked={allowRemix} 
            onChange={setAllowRemix} 
          />
        </div>
      </section>

      <section className="space-y-4">
        <h3 className="text-lg font-semibold text-white flex items-center gap-2">
          <History className="w-5 h-5 text-indigo-400" />
          Advanced Options
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <button className="flex items-center gap-4 p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-white/10 transition-all text-left">
            <div className="p-2 rounded-xl bg-zinc-800 text-zinc-400">
              <Calendar className="w-4 h-4" />
            </div>
            <div>
              <p className="text-sm font-medium text-white">Schedule Post</p>
              <p className="text-xs text-zinc-500">Pick a future time</p>
            </div>
          </button>
          <button className="flex items-center gap-4 p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-white/10 transition-all text-left">
            <div className="p-2 rounded-xl bg-zinc-800 text-zinc-400">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <p className="text-sm font-medium text-white">Save as Draft</p>
              <p className="text-xs text-zinc-500">Finish it later</p>
            </div>
          </button>
        </div>
      </section>
    </div>
  );
}
