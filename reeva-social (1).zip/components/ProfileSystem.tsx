'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Image from 'next/image';
import { 
  Grid, 
  Play, 
  Bookmark, 
  User as UserIcon, 
  Settings, 
  Edit3, 
  Share2,
  MapPin,
  Link as LinkIcon,
  Calendar,
  UserPlus,
  MessageCircle,
  Check,
  MoreHorizontal,
  AlertCircle,
  Ban,
  Info,
  Mail,
  Phone
} from 'lucide-react';

interface ProfileSystemProps {
  onEdit?: () => void;
  isPublic?: boolean;
}

export default function ProfileSystem({ onEdit, isPublic = false }: ProfileSystemProps) {
  const [activeTab, setActiveTab] = useState<'posts' | 'reels' | 'saved'>('posts');
  const [isFollowing, setIsFollowing] = useState(false);
  const [showPublicMenu, setShowPublicMenu] = useState(false);

  const hapticProps = {
    whileTap: { scale: 0.95 },
    transition: { type: "spring" as const, stiffness: 400, damping: 17 }
  };

  const stats = [
    { label: 'Posts', value: '128' },
    { label: 'Followers', value: isPublic ? (isFollowing ? '12.6k' : '12.5k') : '4.2k' },
    { label: 'Following', value: '842' },
  ];

  const publicMenuItems = [
    { label: 'Share Profile', icon: <Share2 className="w-4 h-4" /> },
    { label: 'About this account', icon: <Info className="w-4 h-4" /> },
    { label: 'Restrict', icon: <Ban className="w-4 h-4 text-amber-400" /> },
    { label: 'Block', icon: <Ban className="w-4 h-4 text-red-400" />, danger: true },
    { label: 'Report', icon: <AlertCircle className="w-4 h-4 text-red-400" />, danger: true },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-8 relative">
      {/* Profile Header */}
      <section className="bg-zinc-900/50 backdrop-blur-xl border border-white/10 rounded-[40px] p-8 md:p-12 shadow-2xl relative">
        {isPublic && (
          <div className="absolute top-6 right-6 z-20">
            <button 
              onClick={() => setShowPublicMenu(!showPublicMenu)}
              className="p-2 hover:bg-white/10 rounded-full transition-colors text-zinc-400 hover:text-white"
            >
              <MoreHorizontal className="w-6 h-6" />
            </button>
            <AnimatePresence>
              {showPublicMenu && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setShowPublicMenu(false)} />
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95, y: 10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: 10 }}
                    className="absolute right-0 mt-2 w-56 z-50 bg-zinc-900 border border-white/10 rounded-2xl shadow-2xl p-2 overflow-hidden"
                  >
                    {publicMenuItems.map((item, idx) => (
                      <button
                        key={idx}
                        onClick={() => setShowPublicMenu(false)}
                        className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all
                          ${item.danger ? 'text-red-400 hover:bg-red-500/10' : 'text-zinc-300 hover:bg-white/5 hover:text-white'}`}
                      >
                        {item.icon}
                        {item.label}
                      </button>
                    ))}
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>
        )}

        <div className="flex flex-col md:flex-row items-center gap-8 md:gap-12">
          {/* Avatar */}
          <div className="relative">
            <div className="w-32 h-32 md:w-40 md:h-40 rounded-full p-1 bg-gradient-to-tr from-indigo-500 via-purple-500 to-pink-500 shadow-[0_0_30px_rgba(79,70,229,0.3)]">
              <div className="w-full h-full rounded-full bg-zinc-950 p-1 relative overflow-hidden">
                <Image 
                  src={isPublic ? "https://picsum.photos/seed/2/200" : "https://picsum.photos/seed/me/200"} 
                  alt="Profile" 
                  fill 
                  className="rounded-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
            {!isPublic && (
              <div className="absolute bottom-2 right-2 p-2 bg-indigo-500 rounded-full border-4 border-zinc-950 shadow-lg">
                <Edit3 className="w-4 h-4 text-white" />
              </div>
            )}
            {isPublic && (
              <div className="absolute bottom-2 right-4 w-6 h-6 bg-emerald-500 border-4 border-zinc-950 rounded-full" />
            )}
          </div>

          {/* Info */}
          <div className="flex-1 text-center md:text-left space-y-6">
            <div className="flex flex-col md:flex-row md:items-center gap-4">
              <div>
                <h2 className="text-3xl font-black tracking-tight text-white">{isPublic ? 'Sarah Chen' : 'Ali Hussain'}</h2>
                <p className="text-zinc-400 font-medium">@{isPublic ? 'schen_art' : 'ali_hussain'}</p>
              </div>
              <div className="flex items-center justify-center md:justify-start gap-2 md:ml-auto">
                {isPublic ? (
                  <>
                    <motion.button 
                      {...hapticProps}
                      onClick={() => setIsFollowing(!isFollowing)}
                      className={`px-6 py-2 rounded-xl text-sm font-bold transition-all flex items-center gap-2
                        ${isFollowing 
                          ? 'bg-white/10 text-white border border-white/10' 
                          : 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/20 hover:bg-indigo-600'}`}
                    >
                      {isFollowing ? <><Check className="w-4 h-4" /> Following</> : <><UserPlus className="w-4 h-4" /> Follow</>}
                    </motion.button>
                    <motion.button 
                      {...hapticProps}
                      className="px-4 py-2 bg-white/5 hover:bg-white/10 text-white rounded-xl text-sm font-bold transition-all border border-white/5 flex items-center gap-2"
                    >
                      <MessageCircle className="w-4 h-4" /> Message
                    </motion.button>
                  </>
                ) : (
                  <>
                    <motion.button 
                      {...hapticProps}
                      onClick={onEdit}
                      className="px-6 py-2 bg-indigo-500 hover:bg-indigo-600 rounded-xl text-sm font-bold transition-all shadow-lg shadow-indigo-500/20 text-white"
                    >
                      Edit Profile
                    </motion.button>
                    <motion.button 
                      {...hapticProps}
                      className="p-2 bg-white/5 hover:bg-white/10 rounded-xl border border-white/5 transition-all"
                    >
                      <Settings className="w-5 h-5 text-zinc-400" />
                    </motion.button>
                  </>
                )}
              </div>
            </div>

            {/* Stats */}
            <div className="flex items-center justify-center md:justify-start gap-8 md:gap-12">
              {stats.map((stat) => (
                <div key={stat.label} className="text-center md:text-left">
                  <p className="text-xl font-black text-white">{stat.value}</p>
                  <p className="text-xs text-zinc-500 font-medium uppercase tracking-widest">{stat.label}</p>
                </div>
              ))}
            </div>

            {/* Bio */}
            <div className="space-y-3">
              <p className="text-sm text-zinc-300 leading-relaxed max-w-md">
                {isPublic 
                  ? 'Digital Artist & Illustrator. Creating worlds out of pixels. 🎨✨' 
                  : 'Digital Creator & UI/UX Enthusiast. Exploring the intersection of design and technology. 🚀✨'}
              </p>
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 text-xs text-zinc-500 font-medium">
                <span className="flex items-center gap-1.5"><MapPin className="w-3.5 h-3.5" /> {isPublic ? 'New York, USA' : 'Dubai, UAE'}</span>
                <span className="flex items-center gap-1.5 text-indigo-400"><LinkIcon className="w-3.5 h-3.5" /> <a href="#" className="hover:underline">{isPublic ? 'sarahchen.art' : 'reeva.app/ali'}</a></span>
                <span className="flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5" /> Joined {isPublic ? 'Jan 2023' : 'Feb 2024'}</span>
              </div>
              
              {/* Professional Account Contact Info */}
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 pt-2">
                <a href="mailto:contact@example.com" className="flex items-center gap-2 px-3 py-1.5 bg-indigo-500/10 text-indigo-400 hover:bg-indigo-500/20 rounded-lg text-xs font-bold transition-colors">
                  <Mail className="w-3.5 h-3.5" /> Email
                </a>
                <a href="tel:+1234567890" className="flex items-center gap-2 px-3 py-1.5 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 rounded-lg text-xs font-bold transition-colors">
                  <Phone className="w-3.5 h-3.5" /> Call
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Tabs */}
      <div className="flex justify-center border-b border-white/5">
        {[
          { id: 'posts', label: 'Posts', icon: <Grid className="w-4 h-4" /> },
          { id: 'reels', label: 'Reels', icon: <Play className="w-4 h-4" /> },
          ...(!isPublic ? [{ id: 'saved', label: 'Saved', icon: <Bookmark className="w-4 h-4" /> }] : []),
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center gap-2 px-8 py-4 text-sm font-bold transition-all relative
              ${activeTab === tab.id ? 'text-white' : 'text-zinc-500 hover:text-zinc-300'}`}
          >
            {tab.icon}
            {tab.label}
            {activeTab === tab.id && (
              <motion.div 
                layoutId="profile-tab"
                className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-500 shadow-[0_0_10px_rgba(79,70,229,0.5)]"
              />
            )}
          </button>
        ))}
      </div>

      {/* Grid */}
      <div className="grid grid-cols-3 gap-1 md:gap-4">
        {Array.from({ length: 9 }).map((_, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className="aspect-square relative group cursor-pointer rounded-lg md:rounded-2xl overflow-hidden bg-zinc-900 border border-white/5"
          >
            <Image 
              src={`https://picsum.photos/seed/${isPublic ? 'pub' : 'post'}${i}/500/500`} 
              alt="Post" 
              fill 
              className="object-cover group-hover:scale-110 transition-transform duration-500"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-6 text-white font-bold">
              <span className="flex items-center gap-1.5"><Play className="w-5 h-5 fill-current" /> {1000 + (i * 123) % 500}</span>
              <span className="flex items-center gap-1.5"><Bookmark className="w-5 h-5 fill-current" /> {100 + (i * 47) % 50}</span>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
