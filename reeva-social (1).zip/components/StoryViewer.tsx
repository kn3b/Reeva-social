'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Image from 'next/image';
import { X, Heart, Send, MoreHorizontal, Eye } from 'lucide-react';

interface StoryViewerProps {
  onClose: () => void;
}

export default function StoryViewer({ onClose }: StoryViewerProps) {
  const [progress, setProgress] = useState(0);

  // Simulate progress
  React.useEffect(() => {
    const timer = setInterval(() => {
      setProgress(p => {
        if (p >= 100) {
          clearInterval(timer);
          onClose();
          return 100;
        }
        return p + 1;
      });
    }, 50);
    return () => clearInterval(timer);
  }, [onClose]);

  const hapticProps = {
    whileTap: { scale: 0.9 },
    transition: { type: "spring" as const, stiffness: 400, damping: 17 }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="fixed inset-0 z-[100] bg-black flex items-center justify-center"
    >
      <div className="w-full max-w-md h-full relative bg-zinc-900 overflow-hidden">
        {/* Story Image/Video */}
        <Image 
          src="https://picsum.photos/seed/story1/1080/1920" 
          alt="Story" 
          fill 
          className="object-cover"
          referrerPolicy="no-referrer"
        />
        
        {/* Overlay Gradients */}
        <div className="absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-black/60 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 h-48 bg-gradient-to-t from-black/80 to-transparent" />

        {/* Top Bar */}
        <div className="absolute top-0 inset-x-0 p-4 pt-6 flex flex-col gap-4">
          {/* Progress Bars */}
          <div className="flex gap-1">
            <div className="h-1 flex-1 bg-white/30 rounded-full overflow-hidden">
              <div className="h-full bg-white" style={{ width: '100%' }} />
            </div>
            <div className="h-1 flex-1 bg-white/30 rounded-full overflow-hidden">
              <div className="h-full bg-white" style={{ width: `${progress}%` }} />
            </div>
            <div className="h-1 flex-1 bg-white/30 rounded-full overflow-hidden" />
          </div>

          {/* User Info & Close */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full border-2 border-indigo-500 overflow-hidden relative">
                <Image src="https://picsum.photos/seed/2/100" alt="User" fill className="object-cover" />
              </div>
              <div>
                <p className="text-sm font-bold text-white shadow-sm">Sarah Chen</p>
                <p className="text-[10px] text-white/80 font-medium">2h ago</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <button className="text-white hover:text-zinc-300"><MoreHorizontal className="w-6 h-6" /></button>
              <button onClick={onClose} className="text-white hover:text-zinc-300"><X className="w-8 h-8" /></button>
            </div>
          </div>
        </div>

        {/* Bottom Interaction Bar */}
        <div className="absolute bottom-0 inset-x-0 p-6 flex items-center gap-4">
          <div className="flex-1 relative">
            <input 
              type="text" 
              placeholder="Reply to Sarah..." 
              className="w-full bg-black/40 backdrop-blur-md border border-white/20 rounded-full py-3 px-5 text-sm text-white placeholder-white/60 focus:outline-none focus:border-white/50 transition-all"
            />
          </div>
          <motion.button {...hapticProps} className="p-3 bg-black/40 backdrop-blur-md border border-white/20 rounded-full text-white">
            <Heart className="w-6 h-6" />
          </motion.button>
          <motion.button {...hapticProps} className="p-3 bg-black/40 backdrop-blur-md border border-white/20 rounded-full text-white">
            <Send className="w-6 h-6" />
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
}
