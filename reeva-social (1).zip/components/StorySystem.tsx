'use client';

import React, { useState, useEffect, useCallback } from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  X, 
  ChevronLeft, 
  ChevronRight, 
  Heart, 
  MessageCircle, 
  Send, 
  MoreHorizontal,
  Music,
  Eye,
  Trash2,
  Bookmark,
  Share2,
  Smile
} from 'lucide-react';
import StoryComposer from './StoryComposer';

interface Story {
  id: string;
  user: {
    name: string;
    avatar: string;
  };
  media: string;
  type: 'image' | 'video';
  timestamp: string;
}

const MOCK_STORIES: Story[] = [
  { id: '1', user: { name: 'Sarah Chen', avatar: 'https://picsum.photos/seed/2/100' }, media: 'https://picsum.photos/seed/10/1080/1920', type: 'image', timestamp: '2h ago' },
  { id: '2', user: { name: 'Alex Rivera', avatar: 'https://picsum.photos/seed/1/100' }, media: 'https://picsum.photos/seed/11/1080/1920', type: 'image', timestamp: '5h ago' },
  { id: '3', user: { name: 'Elena Vance', avatar: 'https://picsum.photos/seed/4/100' }, media: 'https://picsum.photos/seed/12/1080/1920', type: 'image', timestamp: '12h ago' },
];

export default function StorySystem() {
  const [viewingStory, setViewingStory] = useState<number | null>(null);
  const [progress, setProgress] = useState(0);
  const [showControls, setShowControls] = useState(false);
  const [isComposing, setIsComposing] = useState(false);

  const handleOpenStory = (idx: number) => {
    setProgress(0);
    setViewingStory(idx);
  };

  const handleNext = useCallback(() => {
    if (viewingStory === null) return;
    if (viewingStory < MOCK_STORIES.length - 1) {
      setViewingStory(viewingStory + 1);
    } else {
      setViewingStory(null);
    }
  }, [viewingStory]);

  const handlePrev = useCallback(() => {
    if (viewingStory === null) return;
    if (viewingStory > 0) {
      setViewingStory(viewingStory - 1);
    } else {
      setViewingStory(null);
    }
  }, [viewingStory]);

  useEffect(() => {
    let interval: any;
    if (viewingStory !== null && !showControls) {
      interval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 100) {
            handleNext();
            return 0;
          }
          return prev + 1;
        });
      }, 50);
    }
    return () => clearInterval(interval);
  }, [viewingStory, handleNext, showControls]);

  return (
    <div className="max-w-2xl mx-auto p-4 space-y-8">
      {/* Story List (Horizontal) */}
      <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
        {/* Create Story */}
        <div className="flex flex-col items-center gap-2 flex-shrink-0" onClick={() => setIsComposing(true)}>
          <div className="relative group cursor-pointer">
            <div className="w-20 h-20 rounded-full p-[3px] bg-zinc-800 border border-white/10 group-hover:border-indigo-500/50 transition-all relative overflow-hidden">
              <Image 
                src="https://picsum.photos/seed/me/100" 
                alt="Your story" 
                fill 
                className="rounded-full object-cover grayscale group-hover:grayscale-0 transition-all"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute bottom-0 right-0 p-1.5 bg-indigo-500 rounded-full border-4 border-zinc-950 shadow-lg">
              <Plus className="w-3 h-3 text-white" />
            </div>
          </div>
          <span className="text-[10px] font-medium text-zinc-500">Your Story</span>
        </div>

        {/* Other Stories */}
        {MOCK_STORIES.map((story, idx) => (
          <div 
            key={story.id} 
            onClick={() => handleOpenStory(idx)}
            className="flex flex-col items-center gap-2 flex-shrink-0 cursor-pointer group"
          >
            <div className="w-20 h-20 rounded-full p-[3px] bg-gradient-to-tr from-indigo-500 via-purple-500 to-pink-500 group-hover:scale-105 transition-transform">
              <div className="w-full h-full rounded-full p-1 bg-zinc-950 relative overflow-hidden">
                <Image 
                  src={story.user.avatar} 
                  alt={story.user.name} 
                  fill 
                  className="rounded-full object-cover p-1"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
            <span className="text-[10px] font-medium text-white">{story.user.name.split(' ')[0]}</span>
          </div>
        ))}
      </div>

      {/* Story Composer Modal */}
      <AnimatePresence>
        {isComposing && <StoryComposer onClose={() => setIsComposing(false)} />}
      </AnimatePresence>

      {/* Story Viewer Modal */}
      <AnimatePresence>
        {viewingStory !== null && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="fixed inset-0 z-[100] bg-black flex items-center justify-center"
          >
            <div className="relative w-full max-w-lg h-full sm:h-[90vh] sm:rounded-3xl overflow-hidden bg-zinc-900 shadow-2xl">
              {/* Progress Bars */}
              <div className="absolute top-4 left-4 right-4 z-20 flex gap-1">
                {MOCK_STORIES.map((_, idx) => (
                  <div key={idx} className="h-1 flex-1 bg-white/20 rounded-full overflow-hidden">
                    {idx === viewingStory && (
                      <motion.div 
                        className="h-full bg-white"
                        style={{ width: `${progress}%` }}
                      />
                    )}
                    {idx < viewingStory && <div className="h-full bg-white" />}
                  </div>
                ))}
              </div>

              {/* Header */}
              <div className="absolute top-8 left-4 right-4 z-20 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="relative w-10 h-10">
                    <Image 
                      src={MOCK_STORIES[viewingStory].user.avatar} 
                      alt={MOCK_STORIES[viewingStory].user.name} 
                      fill 
                      className="rounded-full border border-white/20 object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-white">{MOCK_STORIES[viewingStory].user.name}</p>
                    <p className="text-[10px] text-white/60">{MOCK_STORIES[viewingStory].timestamp}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={() => setShowControls(!showControls)} className="p-2 hover:bg-white/10 rounded-full transition-colors">
                    <MoreHorizontal className="w-5 h-5 text-white" />
                  </button>
                  <button onClick={() => setViewingStory(null)} className="p-2 hover:bg-white/10 rounded-full transition-colors">
                    <X className="w-5 h-5 text-white" />
                  </button>
                </div>
              </div>

              {/* Media */}
              <div className="absolute inset-0 bg-zinc-800">
                <Image 
                  src={MOCK_STORIES[viewingStory].media} 
                  alt="story content"
                  fill
                  className="object-cover"
                  referrerPolicy="no-referrer"
                />
                {/* Navigation Areas */}
                <div className="absolute inset-0 flex">
                  <div className="flex-1 cursor-pointer" onClick={handlePrev} />
                  <div className="flex-1 cursor-pointer" onClick={handleNext} />
                </div>
              </div>

              {/* Footer Controls */}
              <div className="absolute bottom-8 left-4 right-4 z-20 flex items-center gap-4">
                <div className="flex-1 relative">
                  <input 
                    type="text" 
                    placeholder="Reply to story..." 
                    className="w-full bg-white/10 backdrop-blur-md border border-white/20 rounded-full py-3 px-6 text-white placeholder-white/60 focus:outline-none focus:bg-white/20 transition-all"
                  />
                  <Smile className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/60" />
                </div>
                <button className="p-3 bg-white/10 backdrop-blur-md rounded-full text-white hover:bg-white/20 transition-all">
                  <Heart className="w-6 h-6" />
                </button>
                <button className="p-3 bg-white/10 backdrop-blur-md rounded-full text-white hover:bg-white/20 transition-all">
                  <Send className="w-6 h-6" />
                </button>
              </div>

              {/* Advanced Control Panel Overlay */}
              <AnimatePresence>
                {showControls && (
                  <motion.div
                    initial={{ y: '100%' }}
                    animate={{ y: 0 }}
                    exit={{ y: '100%' }}
                    className="absolute inset-x-0 bottom-0 z-50 bg-zinc-900/95 backdrop-blur-xl rounded-t-[32px] p-8 border-t border-white/10"
                  >
                    <div className="w-12 h-1.5 bg-white/10 rounded-full mx-auto mb-8" />
                    <div className="space-y-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Eye className="w-5 h-5 text-indigo-400" />
                          <div>
                            <p className="text-sm font-bold text-white">Story Insights</p>
                            <p className="text-xs text-zinc-500">1.2k viewers • 42 reactions</p>
                          </div>
                        </div>
                        <ChevronRight className="w-4 h-4 text-zinc-500" />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <button className="flex flex-col items-center gap-2 p-4 rounded-2xl bg-white/5 hover:bg-white/10 transition-all">
                          <Bookmark className="w-5 h-5 text-white" />
                          <span className="text-xs text-zinc-400">Highlight</span>
                        </button>
                        <button className="flex flex-col items-center gap-2 p-4 rounded-2xl bg-white/5 hover:bg-white/10 transition-all">
                          <Share2 className="w-5 h-5 text-white" />
                          <span className="text-xs text-zinc-400">Share to Post</span>
                        </button>
                        <button className="flex flex-col items-center gap-2 p-4 rounded-2xl bg-white/5 hover:bg-white/10 transition-all">
                          <Music className="w-5 h-5 text-white" />
                          <span className="text-xs text-zinc-400">Add Music</span>
                        </button>
                        <button className="flex flex-col items-center gap-2 p-4 rounded-2xl bg-red-500/10 hover:bg-red-500/20 transition-all group">
                          <Trash2 className="w-5 h-5 text-red-400" />
                          <span className="text-xs text-red-400">Delete</span>
                        </button>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
