'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Image from 'next/image';
import { 
  MoreHorizontal, 
  Heart, 
  MessageCircle, 
  Share2, 
  Bookmark,
  Edit3,
  Trash2,
  EyeOff,
  Pin,
  BarChart2,
  Zap,
  Check,
  MessageSquareOff,
  X,
  Link as LinkIcon,
  Send,
  AlertCircle,
  Copy,
  Mic,
  Flag
} from 'lucide-react';

interface PostProps {
  user: {
    name: string;
    username: string;
    avatar: string;
  };
  content: string;
  image: string;
  likes: string;
  comments: string;
  onGoToProfile?: () => void;
}

function CommentItem({ i }: { i: number }) {
  const [showOptions, setShowOptions] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const timerRef = React.useRef<NodeJS.Timeout | null>(null);

  const handlePointerDown = () => {
    timerRef.current = setTimeout(() => {
      setShowOptions(true);
    }, 500); // 500ms long press
  };

  const handlePointerUp = () => {
    if (timerRef.current) clearTimeout(timerRef.current);
  };

  const commentText = "This is an amazing post! The composition is just perfect. 🔥";

  return (
    <div 
      className="flex gap-4 relative"
      onPointerDown={handlePointerDown}
      onPointerUp={handlePointerUp}
      onPointerLeave={handlePointerUp}
      onContextMenu={(e) => e.preventDefault()}
    >
      <div className="w-8 h-8 rounded-full bg-indigo-500/20 shrink-0 overflow-hidden relative">
        <Image src={`https://picsum.photos/seed/user${i}/100`} alt="User" fill className="object-cover" />
      </div>
      <div className="flex-1">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-sm font-bold text-white">User {i}</span>
          <span className="text-[10px] text-zinc-500">2h</span>
        </div>
        <p className="text-sm text-zinc-300">{commentText}</p>
        <button className="text-xs font-bold text-zinc-500 mt-2 hover:text-white">Reply</button>
      </div>
      <button 
        onClick={() => setIsLiked(!isLiked)}
        className={`ml-auto self-start ${isLiked ? 'text-rose-500' : 'text-zinc-500 hover:text-rose-500'}`}
      >
        <Heart className={`w-4 h-4 ${isLiked ? 'fill-current' : ''}`} />
      </button>

      <AnimatePresence>
        {showOptions && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="absolute top-full left-12 mt-2 bg-zinc-800 border border-white/10 rounded-xl shadow-xl p-2 flex gap-2 z-50"
          >
            <button 
              onClick={() => { navigator.clipboard.writeText(commentText); setShowOptions(false); }}
              className="p-2 hover:bg-white/10 rounded-lg text-zinc-300 hover:text-white transition-colors flex flex-col items-center gap-1"
            >
              <Copy className="w-4 h-4" />
              <span className="text-[10px]">Copy</span>
            </button>
            <button 
              onClick={() => setShowOptions(false)}
              className="p-2 hover:bg-white/10 rounded-lg text-zinc-300 hover:text-white transition-colors flex flex-col items-center gap-1"
            >
              <MessageCircle className="w-4 h-4" />
              <span className="text-[10px]">Reply</span>
            </button>
            <button 
              onClick={() => setShowOptions(false)}
              className="p-2 hover:bg-red-500/10 rounded-lg text-red-400 transition-colors flex flex-col items-center gap-1"
            >
              <Flag className="w-4 h-4" />
              <span className="text-[10px]">Report</span>
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function PostCard({ user, content, image, likes, comments, onGoToProfile }: PostProps) {
  const [showMenu, setShowMenu] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [showHeartAnim, setShowHeartAnim] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const [showShare, setShowShare] = useState(false);
  const [likeCount, setLikeCount] = useState(parseInt(likes.replace('k', '000')) || 0);
  
  // Post Settings State
  const [isCommentsLocked, setIsCommentsLocked] = useState(false);
  const [isLikesHidden, setIsLikesHidden] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editedContent, setEditedContent] = useState(content);

  const hapticProps = {
    whileTap: { scale: 0.9 },
    transition: { type: "spring" as const, stiffness: 400, damping: 17 }
  };

  const handleDoubleTap = () => {
    if (!isLiked) {
      setIsLiked(true);
      setLikeCount(prev => prev + 1);
    }
    setShowHeartAnim(true);
    setTimeout(() => setShowHeartAnim(false), 1000);
  };

  const toggleLike = () => {
    setIsLiked(!isLiked);
    setLikeCount(prev => isLiked ? prev - 1 : prev + 1);
  };

  const menuItems = [
    { label: 'Edit Post', icon: <Edit3 className="w-4 h-4" />, action: () => { setIsEditing(true); setShowMenu(false); } },
    { label: 'Copy Text', icon: <Copy className="w-4 h-4" />, action: () => { navigator.clipboard.writeText(content); setShowMenu(false); } },
    { label: isCommentsLocked ? 'Unlock Comments' : 'Lock Comments', icon: <MessageSquareOff className="w-4 h-4" />, action: () => { setIsCommentsLocked(!isCommentsLocked); setShowMenu(false); } },
    { label: isLikesHidden ? 'Show Likes' : 'Hide Likes', icon: <EyeOff className="w-4 h-4" />, action: () => { setIsLikesHidden(!isLikesHidden); setShowMenu(false); } },
    { label: 'Pin to Profile', icon: <Pin className="w-4 h-4" />, action: () => setShowMenu(false) },
    { label: 'View Insights', icon: <BarChart2 className="w-4 h-4" />, action: () => setShowMenu(false) },
    { label: 'Promote', icon: <Zap className="w-4 h-4 text-amber-400" />, action: () => setShowMenu(false) },
    { label: 'Delete', icon: <Trash2 className="w-4 h-4 text-red-400" />, danger: true, action: () => setShowMenu(false) },
  ];

  return (
    <div className="bg-zinc-900/50 backdrop-blur-xl border border-white/10 rounded-[32px] overflow-hidden shadow-xl relative">
      {/* Post Header */}
      <div className="p-4 flex items-center justify-between">
        <div 
          className="flex items-center gap-3 cursor-pointer group"
          onClick={onGoToProfile}
        >
          <div className="relative w-10 h-10">
            <Image 
              src={user.avatar} 
              alt={user.name} 
              fill 
              className="rounded-full object-cover border border-white/10 group-hover:border-indigo-500/50 transition-colors"
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <p className="text-sm font-bold text-white group-hover:text-indigo-400 transition-colors">{user.name}</p>
            <p className="text-xs text-zinc-500">@{user.username} • 2h ago</p>
          </div>
        </div>
        <div className="relative">
          <button 
            onClick={() => setShowMenu(!showMenu)}
            className="p-2 hover:bg-white/5 rounded-full transition-colors text-zinc-400 hover:text-white"
          >
            <MoreHorizontal className="w-5 h-5" />
          </button>
          
          <AnimatePresence>
            {showMenu && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setShowMenu(false)} />
                <motion.div
                  initial={{ opacity: 0, scale: 0.95, y: 10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: 10 }}
                  className="absolute right-0 mt-2 w-56 z-50 bg-zinc-900 border border-white/10 rounded-2xl shadow-2xl p-2 overflow-hidden"
                >
                  {menuItems.map((item, idx) => (
                    <button
                      key={idx}
                      onClick={item.action}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all
                        ${item.danger ? 'text-red-400 hover:bg-red-500/10' : 'text-zinc-300 hover:bg-white/5 hover:text-white'}`}
                    >
                      {item.icon}
                      {item.label}
                    </button>
                  ))}
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Post Content */}
      <div className="px-4 pb-3">
        {isEditing ? (
          <div className="space-y-2">
            <textarea 
              value={editedContent}
              onChange={(e) => setEditedContent(e.target.value)}
              className="w-full bg-black/20 border border-white/10 rounded-xl p-3 text-sm text-white focus:outline-none focus:border-indigo-500/50 min-h-[100px]"
            />
            <div className="flex justify-end gap-2">
              <button onClick={() => setIsEditing(false)} className="px-4 py-1.5 rounded-lg text-xs font-bold text-zinc-400 hover:text-white">Cancel</button>
              <button onClick={() => setIsEditing(false)} className="px-4 py-1.5 rounded-lg text-xs font-bold bg-indigo-500 text-white hover:bg-indigo-600">Save</button>
            </div>
          </div>
        ) : (
          <p className="text-sm text-zinc-200 leading-relaxed">{editedContent}</p>
        )}
      </div>

      {/* Post Media */}
      <div 
        className="relative aspect-square w-full bg-zinc-800 cursor-pointer"
        onDoubleClick={handleDoubleTap}
      >
        <Image 
          src={image} 
          alt="post media" 
          fill 
          className="object-cover"
          referrerPolicy="no-referrer"
        />
        {/* Double Tap Heart Animation */}
        <AnimatePresence>
          {showHeartAnim && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.5, rotate: -15 }}
              animate={{ opacity: 1, scale: 1.2, rotate: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: -50 }}
              transition={{ type: "spring", damping: 12, stiffness: 200 }}
              className="absolute inset-0 flex items-center justify-center z-10 pointer-events-none"
            >
              <Heart className="w-32 h-32 text-rose-500 fill-current drop-shadow-[0_0_30px_rgba(244,63,94,0.6)]" />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Post Actions */}
      <div className="p-4 flex items-center justify-between">
        <div className="flex items-center gap-4 sm:gap-6">
          <motion.button 
            {...hapticProps} 
            onClick={toggleLike} 
            className="flex items-center gap-2 group"
          >
            <div className={`p-2 rounded-full transition-colors ${isLiked ? 'bg-rose-500/10' : 'hover:bg-white/5'}`}>
              <Heart className={`w-6 h-6 transition-colors ${isLiked ? 'text-rose-500 fill-current' : 'text-zinc-400 group-hover:text-rose-400'}`} />
            </div>
            {!isLikesHidden && (
              <span className={`text-sm font-bold ${isLiked ? 'text-rose-500' : 'text-zinc-400'}`}>
                {likeCount > 1000 ? `${(likeCount/1000).toFixed(1)}k` : likeCount}
              </span>
            )}
          </motion.button>
          
          <motion.button 
            {...hapticProps} 
            onClick={() => !isCommentsLocked && setShowComments(true)} 
            className={`flex items-center gap-2 group ${isCommentsLocked ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            <div className="p-2 rounded-full hover:bg-white/5 transition-colors">
              <MessageCircle className="w-6 h-6 text-zinc-400 group-hover:text-indigo-400 transition-colors" />
            </div>
            {!isCommentsLocked && <span className="text-sm font-bold text-zinc-400 group-hover:text-indigo-400">{comments}</span>}
          </motion.button>
          
          <motion.button 
            {...hapticProps} 
            onClick={() => setShowShare(true)} 
            className="flex items-center gap-2 group"
          >
            <div className="p-2 rounded-full hover:bg-white/5 transition-colors">
              <Share2 className="w-6 h-6 text-zinc-400 group-hover:text-emerald-400 transition-colors" />
            </div>
          </motion.button>
        </div>
        
        <motion.button 
          {...hapticProps} 
          onClick={() => setIsSaved(!isSaved)} 
          className="p-2 rounded-full hover:bg-white/5 transition-colors"
        >
          <Bookmark className={`w-6 h-6 transition-colors ${isSaved ? 'text-indigo-400 fill-current' : 'text-zinc-400 hover:text-indigo-400'}`} />
        </motion.button>
      </div>

      {/* Comments Bottom Sheet */}
      <AnimatePresence>
        {showComments && !isCommentsLocked && (
          <>
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setShowComments(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
            />
            <motion.div 
              initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed inset-x-0 bottom-0 z-50 bg-zinc-900 border-t border-white/10 rounded-t-[40px] h-[70vh] flex flex-col"
            >
              <div className="p-4 flex justify-center shrink-0">
                <div className="w-12 h-1.5 bg-white/20 rounded-full" />
              </div>
              <div className="px-6 pb-4 border-b border-white/5 flex items-center justify-between shrink-0">
                <h3 className="text-lg font-bold text-white">Comments ({comments})</h3>
                <button onClick={() => setShowComments(false)} className="p-2 bg-white/5 rounded-full text-zinc-400 hover:text-white"><X className="w-5 h-5" /></button>
              </div>
              <div className="flex-1 overflow-y-auto p-6 space-y-6">
                {[1, 2, 3, 4].map(i => (
                  <CommentItem key={i} i={i} />
                ))}
              </div>
              <div className="p-6 border-t border-white/5 bg-zinc-900 shrink-0">
                <div className="flex items-center gap-3 bg-white/5 border border-white/10 rounded-full p-2 pr-4">
                  <div className="w-8 h-8 rounded-full bg-indigo-500 shrink-0 overflow-hidden relative">
                    <Image src="https://picsum.photos/seed/me/100" alt="Me" fill className="object-cover" />
                  </div>
                  <input type="text" placeholder="Add a comment..." className="flex-1 bg-transparent text-sm text-white focus:outline-none" />
                  <button className="p-2 text-zinc-400 hover:text-indigo-400 transition-colors">
                    <Mic className="w-4 h-4" />
                  </button>
                  <button className="text-indigo-400 font-bold text-sm">Post</button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Share Bottom Sheet */}
      <AnimatePresence>
        {showShare && (
          <>
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setShowShare(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
            />
            <motion.div 
              initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed inset-x-0 bottom-0 z-50 bg-zinc-900 border-t border-white/10 rounded-t-[40px] p-6 pb-12"
            >
              <div className="w-12 h-1.5 bg-white/20 rounded-full mx-auto mb-6" />
              <h3 className="text-lg font-bold text-white mb-6 text-center">Share to</h3>
              
              <div className="flex gap-4 overflow-x-auto pb-6 scrollbar-hide">
                {[1, 2, 3, 4, 5].map(i => (
                  <div key={i} className="flex flex-col items-center gap-2 shrink-0">
                    <div className="w-16 h-16 rounded-full bg-white/5 border border-white/10 overflow-hidden relative">
                      <Image src={`https://picsum.photos/seed/friend${i}/100`} alt="Friend" fill className="object-cover" />
                    </div>
                    <span className="text-xs text-white font-medium">Friend {i}</span>
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-4 gap-4 border-t border-white/5 pt-6">
                <button className="flex flex-col items-center gap-2 group">
                  <div className="w-12 h-12 rounded-full bg-white/5 group-hover:bg-white/10 flex items-center justify-center transition-colors">
                    <LinkIcon className="w-5 h-5 text-zinc-300" />
                  </div>
                  <span className="text-[10px] text-zinc-400">Copy Link</span>
                </button>
                <button className="flex flex-col items-center gap-2 group">
                  <div className="w-12 h-12 rounded-full bg-white/5 group-hover:bg-white/10 flex items-center justify-center transition-colors">
                    <Send className="w-5 h-5 text-zinc-300" />
                  </div>
                  <span className="text-[10px] text-zinc-400">Message</span>
                </button>
                <button className="flex flex-col items-center gap-2 group">
                  <div className="w-12 h-12 rounded-full bg-white/5 group-hover:bg-white/10 flex items-center justify-center transition-colors">
                    <Bookmark className="w-5 h-5 text-zinc-300" />
                  </div>
                  <span className="text-[10px] text-zinc-400">Save</span>
                </button>
                <button className="flex flex-col items-center gap-2 group">
                  <div className="w-12 h-12 rounded-full bg-white/5 group-hover:bg-white/10 flex items-center justify-center transition-colors">
                    <AlertCircle className="w-5 h-5 text-rose-400" />
                  </div>
                  <span className="text-[10px] text-rose-400">Report</span>
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

