'use client';

import React, { useState, useEffect, useRef } from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Image as ImageIcon, 
  Video, 
  X, 
  Plus, 
  Hash, 
  AtSign, 
  Smile, 
  MapPin, 
  Music, 
  Sparkles, 
  ChevronRight,
  Send,
  Loader2,
  CheckCircle2
} from 'lucide-react';
import { useDropzone } from 'react-dropzone';
import TextareaAutosize from 'react-textarea-autosize';
import EmojiPicker, { Theme } from 'emoji-picker-react';
import { 
  DndContext, 
  closestCenter, 
  KeyboardSensor, 
  PointerSensor, 
  useSensor, 
  useSensors 
} from '@dnd-kit/core';
import { 
  arrayMove, 
  SortableContext, 
  sortableKeyboardCoordinates, 
  horizontalListSortingStrategy,
  useSortable
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { suggestCaption, generateHashtags } from '@/lib/ai';

interface MediaItem {
  id: string;
  url: string;
  type: 'image' | 'video';
  file: File;
}

const SortableMedia = ({ item, onRemove }: { item: MediaItem, onRemove: (id: string) => void }) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
  } = useSortable({ id: item.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div 
      ref={setNodeRef} 
      style={style} 
      className="relative group w-24 h-24 rounded-xl overflow-hidden border border-white/10"
    {...attributes} {...listeners}>
      {item.type === 'image' ? (
        <Image 
          src={item.url} 
          alt="upload" 
          fill 
          className="object-cover" 
          unoptimized 
          referrerPolicy="no-referrer"
        />
      ) : (
        <video src={item.url} className="w-full h-full object-cover" />
      )}
      <button 
        onClick={(e) => { e.stopPropagation(); onRemove(item.id); }}
        className="absolute top-1 right-1 p-1 bg-black/50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
      >
        <X className="w-3 h-3 text-white" />
      </button>
    </div>
  );
};

export default function PostComposer() {
  const [caption, setCaption] = useState('');
  const [media, setMedia] = useState<MediaItem[]>([]);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);
  const [publishSuccess, setPublishSuccess] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const onDrop = (acceptedFiles: File[]) => {
    const newMedia = acceptedFiles.map(file => ({
      id: Math.random().toString(36).substr(2, 9),
      url: URL.createObjectURL(file),
      type: file.type.startsWith('video') ? 'video' as const : 'image' as const,
      file
    }));
    setMedia([...media, ...newMedia]);
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ 
    onDrop,
    accept: {
      'image/*': [],
      'video/*': []
    }
  });

  const handleDragEnd = (event: any) => {
    const { active, over } = event;
    if (active.id !== over.id) {
      setMedia((items) => {
        const oldIndex = items.findIndex((i) => i.id === active.id);
        const newIndex = items.findIndex((i) => i.id === over.id);
        return arrayMove(items, oldIndex, newIndex);
      });
    }
  };

  const handleAiCaption = async () => {
    if (!caption && media.length === 0) return;
    setIsAiLoading(true);
    const suggestions = await suggestCaption(caption || "a beautiful day");
    if (suggestions.length > 0) {
      setCaption(suggestions[0]);
    }
    setIsAiLoading(false);
  };

  const handleAiHashtags = async () => {
    setIsAiLoading(true);
    const hashtags = await generateHashtags(caption);
    setCaption(prev => prev + "\n\n" + hashtags.map((h: string) => `#${h}`).join(' '));
    setIsAiLoading(false);
  };

  const handlePublish = async () => {
    if (media.length === 0 && !caption) return;
    setIsPublishing(true);
    setUploadProgress(0);
    
    // Simulate upload progress
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setPublishSuccess(true);
          setTimeout(() => {
            setIsPublishing(false);
            setPublishSuccess(false);
            setCaption('');
            setMedia([]);
          }, 2000);
          return 100;
        }
        return prev + 5;
      });
    }, 100);
  };

  const highlightHashtags = (text: string) => {
    return text.split(/(\s+)/).map((part, i) => {
      if (part.startsWith('#')) return <span key={i} className="text-indigo-400 font-medium">{part}</span>;
      if (part.startsWith('@')) return <span key={i} className="text-emerald-400 font-medium">{part}</span>;
      return part;
    });
  };

  return (
    <div className="max-w-2xl mx-auto p-4 space-y-6">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-zinc-900/50 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-2xl overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-white">Create Post</h2>
          <div className="flex gap-2">
            <button 
              onClick={handleAiCaption}
              disabled={isAiLoading}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-indigo-400 transition-colors flex items-center gap-2 text-sm"
            >
              {isAiLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              AI Caption
            </button>
            <button 
              onClick={handleAiHashtags}
              disabled={isAiLoading}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-emerald-400 transition-colors flex items-center gap-2 text-sm"
            >
              <Hash className="w-4 h-4" />
              AI Tags
            </button>
          </div>
        </div>

        {/* Media Upload Area */}
        <div className="space-y-4 mb-6">
          <div 
            {...getRootProps()} 
            className={`border-2 border-dashed rounded-2xl p-8 transition-all flex flex-col items-center justify-center gap-3 cursor-pointer
              ${isDragActive ? 'border-indigo-500 bg-indigo-500/10' : 'border-white/10 hover:border-white/20 bg-white/5'}`}
          >
            <input {...getInputProps()} />
            <div className="p-3 bg-indigo-500/20 rounded-full">
              <Plus className="w-6 h-6 text-indigo-400" />
            </div>
            <p className="text-zinc-400 text-sm">Drag & drop or click to upload</p>
            <div className="flex gap-4 text-xs text-zinc-500">
              <span className="flex items-center gap-1"><ImageIcon className="w-3 h-3" /> Images</span>
              <span className="flex items-center gap-1"><Video className="w-3 h-3" /> Videos</span>
            </div>
          </div>

          {media.length > 0 && (
            <DndContext 
              sensors={sensors}
              collisionDetection={closestCenter}
              onDragEnd={handleDragEnd}
            >
              <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
                <SortableContext 
                  items={media.map(m => m.id)}
                  strategy={horizontalListSortingStrategy}
                >
                  {media.map((item) => (
                    <SortableMedia 
                      key={item.id} 
                      item={item} 
                      onRemove={(id) => setMedia(media.filter(m => m.id !== id))} 
                    />
                  ))}
                </SortableContext>
              </div>
            </DndContext>
          )}
        </div>

        {/* Caption Area */}
        <div className="relative group">
          <div className="absolute inset-0 bg-indigo-500/5 blur-xl opacity-0 group-focus-within:opacity-100 transition-opacity rounded-2xl" />
          <div className="relative bg-white/5 border border-white/10 rounded-2xl p-4 focus-within:border-indigo-500/50 transition-all">
            <TextareaAutosize
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              placeholder="What's on your mind?"
              className="w-full bg-transparent border-none focus:ring-0 text-white placeholder-zinc-500 resize-none min-h-[120px]"
            />
            <div className="flex items-center justify-between mt-4 pt-4 border-t border-white/5">
              <div className="flex gap-3">
                <button onClick={() => setShowEmojiPicker(!showEmojiPicker)} className="p-2 hover:bg-white/5 rounded-lg text-zinc-400 hover:text-white transition-colors">
                  <Smile className="w-5 h-5" />
                </button>
                <button className="p-2 hover:bg-white/5 rounded-lg text-zinc-400 hover:text-white transition-colors">
                  <MapPin className="w-5 h-5" />
                </button>
                <button className="p-2 hover:bg-white/5 rounded-lg text-zinc-400 hover:text-white transition-colors">
                  <Music className="w-5 h-5" />
                </button>
              </div>
              <span className="text-xs text-zinc-500 font-mono">
                {caption.length} characters
              </span>
            </div>
          </div>
          
          {showEmojiPicker && (
            <div className="absolute bottom-full left-0 mb-2 z-50">
              <div className="fixed inset-0" onClick={() => setShowEmojiPicker(false)} />
              <div className="relative">
                <EmojiPicker 
                  theme={Theme.DARK}
                  onEmojiClick={(emoji) => setCaption(prev => prev + emoji.emoji)}
                />
              </div>
            </div>
          )}
        </div>

        {/* Publish Button */}
        <div className="mt-8">
          <button
            onClick={handlePublish}
            disabled={isPublishing || (media.length === 0 && !caption)}
            className={`w-full relative group overflow-hidden rounded-2xl p-4 font-semibold transition-all
              ${isPublishing ? 'bg-zinc-800 cursor-not-allowed' : 'bg-gradient-to-r from-[#5254FF] to-[#7172FA] hover:shadow-[0_0_20px_rgba(82,84,255,0.4)] active:scale-[0.98]'}`}
          >
            <AnimatePresence mode="wait">
              {publishSuccess ? (
                <motion.div 
                  key="success"
                  initial={{ opacity: 0, scale: 0.5 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex items-center justify-center gap-2 text-white"
                >
                  <CheckCircle2 className="w-5 h-5" />
                  Published Successfully
                </motion.div>
              ) : isPublishing ? (
                <motion.div 
                  key="loading"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="relative z-10 flex items-center justify-center gap-3 text-white"
                >
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Uploading... {uploadProgress}%
                </motion.div>
              ) : (
                <motion.div 
                  key="default"
                  className="flex items-center justify-center gap-2 text-white"
                >
                  <Send className="w-5 h-5" />
                  Publish Post
                </motion.div>
              )}
            </AnimatePresence>
            
            {isPublishing && (
              <motion.div 
                className="absolute inset-0 bg-indigo-500/20 origin-left"
                initial={{ scaleX: 0 }}
                animate={{ scaleX: uploadProgress / 100 }}
              />
            )}
          </button>
        </div>
      </motion.div>
    </div>
  );
}
