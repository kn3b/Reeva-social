'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Image from 'next/image';
import { 
  Search, Edit3, MoreVertical, CheckCheck, Phone, Video, ChevronLeft, 
  Smile, Paperclip, Send, MapPin, FileText, Image as ImageIcon, Camera, 
  Shield, Mic, MicOff, VideoOff, Users, X, Heart, Archive, BellOff, Trash2, 
  Plus, FileArchive, Sparkles, UserMinus, FileDigit, PlayCircle, Palette, Ban, Map
} from 'lucide-react';

interface Message {
  id: string;
  senderId: string;
  text?: string;
  type: 'text' | 'image' | 'video' | 'file' | 'location';
  mediaUrl?: string;
  fileName?: string;
  fileSize?: string;
  time: string;
  reaction?: string;
}

type ChatTheme = 'default' | 'love' | 'friendship' | 'nature' | 'royal';

interface Chat {
  id: string;
  isGroup?: boolean;
  user: {
    name: string;
    avatar: string;
    isOnline: boolean;
    lastSeen?: string;
    inChat?: boolean;
  };
  messages: Message[];
  unreadCount: number;
  theme: ChatTheme;
}

const CURRENT_USER_ID = 'me';

const MOCK_CHATS: Chat[] = [
  { 
    id: '1', 
    user: { name: 'Sarah Chen', avatar: 'https://picsum.photos/seed/2/100', isOnline: true, inChat: true }, 
    unreadCount: 2,
    theme: 'default',
    messages: [
      { id: 'm1', senderId: '1', type: 'text', text: 'Hey! Did you see the new design?', time: '10:40 AM' },
      { id: 'm2', senderId: CURRENT_USER_ID, type: 'text', text: 'Yes! The haptic feedback is amazing.', time: '10:42 AM' },
      { id: 'm3', senderId: '1', type: 'text', text: 'Check out this prototype video I made.', time: '10:45 AM' },
      { id: 'm4', senderId: '1', type: 'video', mediaUrl: 'https://picsum.photos/seed/vid/400/300', fileName: 'prototype_v2.mp4', fileSize: '12.4 MB', time: '10:46 AM' },
    ]
  },
  { 
    id: '2', 
    isGroup: true,
    user: { name: 'Design Team 🚀', avatar: 'https://picsum.photos/seed/team/100', isOnline: true }, 
    unreadCount: 0,
    theme: 'friendship',
    messages: [
      { id: 'm1', senderId: '2', type: 'text', text: 'Meeting at 3 PM guys!', time: '9:00 AM' },
      { id: 'm2', senderId: '3', type: 'file', fileName: 'Q3_Report.pdf', fileSize: '2.1 MB', time: '9:15 AM' },
      { id: 'm3', senderId: '2', type: 'location', text: 'Dubai Design District', time: '9:20 AM' },
    ]
  },
];

const REACTIONS = ['❤️', '😂', '😮', '😢', '🙏', '🔥'];

export default function MessagesSystem() {
  const [chats, setChats] = useState<Chat[]>(MOCK_CHATS);
  const [selectedChat, setSelectedChat] = useState<Chat | null>(null);
  const [messageInput, setMessageInput] = useState('');
  const [focusedMessage, setFocusedMessage] = useState<Message | null>(null);
  const [showAttachments, setShowAttachments] = useState(false);
  const [activeCall, setActiveCall] = useState<'voice' | 'video' | 'meeting' | null>(null);
  const [chatOptionsId, setChatOptionsId] = useState<string | null>(null);
  
  // Active Chat Menu States
  const [chatMenuOpen, setChatMenuOpen] = useState(false);
  const [themeMenuOpen, setThemeMenuOpen] = useState(false);

  const hapticProps = {
    whileTap: { scale: 0.95 },
    transition: { type: "spring" as const, stiffness: 400, damping: 17 }
  };

  // Simulate presence
  useEffect(() => {
    if (selectedChat) {
      const timer = setTimeout(() => {
        setChats(prev => prev.map(c => 
          c.id === selectedChat.id ? { ...c, user: { ...c.user, inChat: true } } : c
        ));
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [selectedChat]);

  const handleSendMessage = (text: string = messageInput, type: Message['type'] = 'text') => {
    if (!text.trim() && type === 'text') return;
    if (!selectedChat) return;
    
    const newMessage: Message = {
      id: Date.now().toString(),
      senderId: CURRENT_USER_ID,
      type,
      text: type === 'text' ? text : type === 'location' ? 'Burj Khalifa, Dubai' : undefined,
      mediaUrl: type === 'image' ? 'https://picsum.photos/seed/new/400/300' : undefined,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChats(prev => prev.map(c => 
      c.id === selectedChat.id 
        ? { ...c, messages: [...c.messages, newMessage] }
        : c
    ));
    setMessageInput('');
    setShowAttachments(false);
  };

  const handleReaction = (emoji: string) => {
    if (!focusedMessage || !selectedChat) return;

    let newTheme = selectedChat.theme;
    if (emoji === '❤️') newTheme = 'love';
    if (emoji === '🙏' || emoji === '😂') newTheme = 'friendship';

    setChats(prev => prev.map(c => 
      c.id === selectedChat.id 
        ? { 
            ...c, 
            theme: newTheme,
            messages: c.messages.map(m => m.id === focusedMessage.id ? { ...m, reaction: emoji } : m)
          }
        : c
    ));
    setFocusedMessage(null);
  };

  const changeTheme = (theme: ChatTheme) => {
    if (!selectedChat) return;
    setChats(prev => prev.map(c => c.id === selectedChat.id ? { ...c, theme } : c));
    setThemeMenuOpen(false);
    setChatMenuOpen(false);
  };

  const renderCallUI = () => (
    <div className="fixed inset-0 z-50 bg-zinc-950 flex flex-col">
      {/* Secure Call Header */}
      <div className="absolute top-0 left-0 right-0 p-6 flex justify-between items-center z-10 bg-gradient-to-b from-black/80 to-transparent">
        <div className="flex items-center gap-2 text-emerald-400 bg-emerald-500/10 px-3 py-1.5 rounded-full border border-emerald-500/20">
          <Shield className="w-4 h-4" />
          <span className="text-xs font-bold">End-to-End Encrypted • Screen Recording Blocked</span>
        </div>
        <button onClick={() => setActiveCall(null)} className="p-2 bg-white/10 rounded-full text-white hover:bg-white/20">
          <X className="w-6 h-6" />
        </button>
      </div>

      {/* Video Grid (Simulated) */}
      <div className="flex-1 relative">
        {activeCall !== 'voice' && (
          <Image src="https://picsum.photos/seed/call/1080/1920" alt="Video" fill className="object-cover" />
        )}
        <div className="absolute inset-0 bg-black/40" />
        
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
          <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-white/20 mb-6 relative">
            <Image src={selectedChat?.user.avatar || ''} alt="Caller" fill className="object-cover" />
          </div>
          <h2 className="text-3xl font-bold mb-2">{selectedChat?.user.name}</h2>
          <p className="text-white/70">{activeCall === 'meeting' ? 'Group Meeting' : 'Ringing...'}</p>
        </div>

        {/* Self View */}
        {activeCall !== 'voice' && (
          <div className="absolute bottom-32 right-6 w-32 h-48 bg-zinc-800 rounded-2xl border-2 border-white/20 overflow-hidden shadow-2xl">
             <Image src="https://picsum.photos/seed/me/400/600" alt="Self" fill className="object-cover" />
          </div>
        )}
      </div>

      {/* Call Controls */}
      <div className="h-32 bg-zinc-900/90 backdrop-blur-xl border-t border-white/10 flex items-center justify-center gap-6 px-6">
        <motion.button {...hapticProps} className="p-4 bg-white/10 rounded-full text-white hover:bg-white/20">
          <Mic className="w-6 h-6" />
        </motion.button>
        <motion.button {...hapticProps} className="p-4 bg-white/10 rounded-full text-white hover:bg-white/20">
          <Video className="w-6 h-6" />
        </motion.button>
        <motion.button {...hapticProps} className="p-4 bg-white/10 rounded-full text-white hover:bg-white/20">
          <Sparkles className="w-6 h-6" />
        </motion.button>
        {activeCall === 'meeting' && (
          <motion.button {...hapticProps} className="p-4 bg-indigo-500/20 rounded-full text-indigo-400 hover:bg-indigo-500/30">
            <Users className="w-6 h-6" />
          </motion.button>
        )}
        <motion.button {...hapticProps} onClick={() => setActiveCall(null)} className="p-4 bg-red-500 rounded-full text-white shadow-[0_0_20px_rgba(239,68,68,0.4)]">
          <Phone className="w-6 h-6 rotate-[135deg]" />
        </motion.button>
      </div>
    </div>
  );

  const renderFocusedMessage = () => (
    <AnimatePresence>
      {focusedMessage && (
        <motion.div 
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
        >
          <div className="absolute inset-0 bg-zinc-950/80 backdrop-blur-md" onClick={() => setFocusedMessage(null)} />
          
          <div className="relative z-10 flex flex-col items-center gap-6 w-full max-w-md">
            {/* Reactions */}
            <motion.div 
              initial={{ y: 20, scale: 0.9 }} animate={{ y: 0, scale: 1 }}
              className="bg-zinc-900 border border-white/10 rounded-full px-6 py-3 flex gap-4 shadow-2xl"
            >
              {REACTIONS.map(emoji => (
                <motion.button 
                  key={emoji} {...hapticProps} onClick={() => handleReaction(emoji)}
                  className="text-3xl hover:scale-125 transition-transform"
                >
                  {emoji}
                </motion.button>
              ))}
            </motion.div>

            {/* The Message */}
            <div className={`p-4 rounded-2xl text-sm text-white shadow-2xl ${focusedMessage.senderId === CURRENT_USER_ID ? 'bg-indigo-500' : 'bg-zinc-800 border border-white/10'}`}>
              {focusedMessage.text || 'Media Message'}
            </div>

            {/* Options */}
            <div className="bg-zinc-900 border border-white/10 rounded-2xl overflow-hidden w-full shadow-2xl">
              <button className="w-full p-4 text-left text-sm text-white hover:bg-white/5 border-b border-white/5">Reply</button>
              <button className="w-full p-4 text-left text-sm text-white hover:bg-white/5 border-b border-white/5">Forward</button>
              <button className="w-full p-4 text-left text-sm text-white hover:bg-white/5 border-b border-white/5">Copy</button>
              <button className="w-full p-4 text-left text-sm text-red-400 hover:bg-red-500/10">Delete</button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );

  const getThemeClasses = (theme: ChatTheme, isMe: boolean) => {
    if (!isMe) return 'bg-white/10 backdrop-blur-md border border-white/10 text-white rounded-tl-none';
    switch (theme) {
      case 'love': return 'bg-rose-500 text-white rounded-tr-none shadow-rose-500/20';
      case 'friendship': return 'bg-blue-500 text-white rounded-tr-none shadow-blue-500/20';
      case 'nature': return 'bg-emerald-500 text-white rounded-tr-none shadow-emerald-500/20';
      case 'royal': return 'bg-purple-500 text-white rounded-tr-none shadow-purple-500/20';
      default: return 'bg-indigo-500 text-white rounded-tr-none shadow-indigo-500/20';
    }
  };

  const renderActiveChat = () => {
    if (!selectedChat) return null;
    const isLoveTheme = selectedChat.theme === 'love';
    const isFriendTheme = selectedChat.theme === 'friendship';
    const isNatureTheme = selectedChat.theme === 'nature';
    const isRoyalTheme = selectedChat.theme === 'royal';

    return (
      <motion.div 
        key="active-chat"
        initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }}
        className="h-[calc(100vh-180px)] flex flex-col bg-zinc-950/50 dark:bg-white/5 backdrop-blur-xl border border-white/10 rounded-[40px] overflow-hidden shadow-2xl relative"
      >
        {/* Dynamic Theme Background */}
        {isLoveTheme && <div className="absolute inset-0 bg-gradient-to-br from-rose-500/10 to-pink-500/5 pointer-events-none" />}
        {isFriendTheme && <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-cyan-500/5 pointer-events-none" />}
        {isNatureTheme && <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/10 to-teal-500/5 pointer-events-none" />}
        {isRoyalTheme && <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-fuchsia-500/5 pointer-events-none" />}

        {activeCall && renderCallUI()}
        {renderFocusedMessage()}

        {/* Chat Header */}
        <div className="p-4 sm:p-6 border-b border-white/10 flex items-center justify-between bg-white/5 relative z-10">
          <div className="flex items-center gap-3 sm:gap-4">
            <motion.button {...hapticProps} onClick={() => {
              setChats(prev => prev.map(c => c.id === selectedChat.id ? { ...c, user: { ...c.user, inChat: false } } : c));
              setSelectedChat(null);
            }} className="p-2 -ml-2 hover:bg-white/10 rounded-full text-zinc-400 hover:text-white transition-colors">
              <ChevronLeft className="w-6 h-6" />
            </motion.button>
            <div className="relative">
              <div className="w-10 h-10 rounded-full relative overflow-hidden border border-white/10">
                <Image src={selectedChat.user.avatar} alt={selectedChat.user.name} fill className="object-cover" referrerPolicy="no-referrer" />
              </div>
              {selectedChat.user.isOnline && <div className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-zinc-950 rounded-full" />}
            </div>
            <div>
              <p className="text-sm font-bold text-white flex items-center gap-2">
                {selectedChat.user.name}
                {isLoveTheme && <Heart className="w-3 h-3 text-rose-500 fill-current animate-pulse" />}
              </p>
              <p className="text-[10px] text-zinc-500">
                {selectedChat.user.inChat ? (
                  <span className="text-indigo-400 font-medium">In chat right now 👀</span>
                ) : selectedChat.user.isOnline ? 'Online' : `Last seen ${selectedChat.user.lastSeen}`}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1 sm:gap-2 relative">
            <motion.button {...hapticProps} onClick={() => setActiveCall('voice')} className="p-2 sm:p-3 hover:bg-white/10 rounded-xl text-zinc-400 hover:text-white transition-all"><Phone className="w-5 h-5" /></motion.button>
            <motion.button {...hapticProps} onClick={() => setActiveCall(selectedChat.isGroup ? 'meeting' : 'video')} className="p-2 sm:p-3 hover:bg-white/10 rounded-xl text-zinc-400 hover:text-white transition-all"><Video className="w-5 h-5" /></motion.button>
            <motion.button {...hapticProps} onClick={() => setChatMenuOpen(!chatMenuOpen)} className="p-2 sm:p-3 hover:bg-white/10 rounded-xl text-zinc-400 hover:text-white transition-all"><MoreVertical className="w-5 h-5" /></motion.button>
            
            {/* Top Right Chat Menu */}
            <AnimatePresence>
              {chatMenuOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => { setChatMenuOpen(false); setThemeMenuOpen(false); }} />
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95, y: -10 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95, y: -10 }}
                    className="absolute top-full right-0 mt-2 w-56 bg-zinc-900 border border-white/10 rounded-2xl shadow-2xl overflow-hidden z-50"
                  >
                    {!themeMenuOpen ? (
                      <>
                        <button onClick={() => setThemeMenuOpen(true)} className="w-full flex items-center gap-3 px-4 py-3 text-sm text-white hover:bg-white/5 transition-colors">
                          <Palette className="w-4 h-4 text-indigo-400" /> Change Theme
                        </button>
                        <button className="w-full flex items-center gap-3 px-4 py-3 text-sm text-white hover:bg-white/5 transition-colors">
                          <Search className="w-4 h-4 text-zinc-400" /> Search Chat
                        </button>
                        <button className="w-full flex items-center gap-3 px-4 py-3 text-sm text-white hover:bg-white/5 transition-colors">
                          <ImageIcon className="w-4 h-4 text-zinc-400" /> View Media
                        </button>
                        <button className="w-full flex items-center gap-3 px-4 py-3 text-sm text-red-400 hover:bg-red-500/10 transition-colors border-t border-white/5">
                          <Ban className="w-4 h-4" /> Block User
                        </button>
                      </>
                    ) : (
                      <>
                        <button onClick={() => setThemeMenuOpen(false)} className="w-full flex items-center gap-3 px-4 py-3 text-sm text-zinc-400 hover:text-white hover:bg-white/5 transition-colors border-b border-white/5">
                          <ChevronLeft className="w-4 h-4" /> Back
                        </button>
                        {(['default', 'love', 'friendship', 'nature', 'royal'] as ChatTheme[]).map(t => (
                          <button key={t} onClick={() => changeTheme(t)} className="w-full flex items-center gap-3 px-4 py-3 text-sm text-white hover:bg-white/5 transition-colors capitalize">
                            <div className={`w-3 h-3 rounded-full ${t === 'love' ? 'bg-rose-500' : t === 'friendship' ? 'bg-blue-500' : t === 'nature' ? 'bg-emerald-500' : t === 'royal' ? 'bg-purple-500' : 'bg-zinc-500'}`} />
                            {t}
                          </button>
                        ))}
                      </>
                    )}
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 scrollbar-hide relative z-10">
          {selectedChat.messages.map((msg) => {
            const isMe = msg.senderId === CURRENT_USER_ID;
            return (
              <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                <motion.div 
                  {...hapticProps}
                  onClick={() => setFocusedMessage(msg)}
                  className={`relative max-w-[85%] sm:max-w-[70%] cursor-pointer group`}
                >
                  {/* Message Bubble */}
                  <div className={`p-3 sm:p-4 rounded-2xl text-sm shadow-lg transition-all ${getThemeClasses(selectedChat.theme, isMe)}`}>
                    {/* Media Content */}
                    {msg.type === 'image' && (
                      <div className="relative w-full h-48 rounded-xl overflow-hidden mb-2">
                        <Image src={msg.mediaUrl || ''} alt="Image" fill className="object-cover" />
                      </div>
                    )}
                    {msg.type === 'video' && (
                      <div className="relative w-full h-48 rounded-xl overflow-hidden mb-2 bg-black flex items-center justify-center">
                        <Image src={msg.mediaUrl || ''} alt="Video" fill className="object-cover opacity-50" />
                        <PlayCircle className="w-12 h-12 text-white absolute" />
                        <div className="absolute top-2 right-2 bg-black/50 px-2 py-1 rounded text-[10px] font-bold">1:59</div>
                      </div>
                    )}
                    {msg.type === 'file' && (
                      <div className="flex items-center gap-3 p-3 bg-black/20 rounded-xl mb-2">
                        <div className="p-2 bg-white/10 rounded-lg">
                          {msg.fileName?.endsWith('.pdf') ? <FileText className="w-6 h-6" /> : <FileArchive className="w-6 h-6" />}
                        </div>
                        <div className="flex-1 overflow-hidden">
                          <p className="text-sm font-bold truncate">{msg.fileName}</p>
                          <p className="text-[10px] opacity-70">{msg.fileSize} • Document</p>
                        </div>
                      </div>
                    )}
                    {msg.type === 'location' && (
                      <div className="relative w-full sm:w-64 h-48 rounded-xl overflow-hidden mb-2 border border-white/10">
                        <iframe 
                          title="map"
                          width="100%" 
                          height="100%" 
                          frameBorder="0" 
                          scrolling="no" 
                          marginHeight={0} 
                          marginWidth={0} 
                          src={`https://maps.google.com/maps?q=${msg.text || 'Dubai'}&t=&z=13&ie=UTF8&iwloc=&output=embed`}
                        />
                        <div className="absolute bottom-0 left-0 right-0 bg-black/60 backdrop-blur-md p-2 text-xs text-white flex items-center gap-2">
                          <MapPin className="w-3 h-3 text-emerald-400" />
                          <span className="truncate">{msg.text || 'Shared Location'}</span>
                        </div>
                      </div>
                    )}
                    
                    {/* Text Content */}
                    {msg.text && msg.type !== 'location' && <p className="leading-relaxed">{msg.text}</p>}

                    {/* Meta */}
                    <div className={`flex items-center justify-end gap-1 mt-2 ${isMe ? 'opacity-90' : 'text-zinc-400'}`}>
                      <span className="text-[9px] font-medium">{msg.time}</span>
                      {isMe && <CheckCheck className="w-3.5 h-3.5 text-blue-400" />}
                    </div>
                  </div>

                  {/* Reaction Badge */}
                  {msg.reaction && (
                    <div className={`absolute -bottom-3 ${isMe ? '-left-2' : '-right-2'} bg-zinc-800 border border-white/10 rounded-full p-1 shadow-xl text-sm`}>
                      {msg.reaction}
                    </div>
                  )}
                </motion.div>
              </div>
            );
          })}
        </div>

        {/* Input Area */}
        <div className="p-4 bg-white/5 border-t border-white/10 relative z-20">
          <AnimatePresence>
            {showAttachments && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 20 }}
                className="absolute bottom-full left-4 mb-4 bg-zinc-900 border border-white/10 rounded-2xl p-4 shadow-2xl grid grid-cols-4 gap-4 w-72"
              >
                {[
                  { icon: <ImageIcon className="w-6 h-6 text-blue-400" />, label: 'Gallery', action: () => handleSendMessage('', 'image') },
                  { icon: <Camera className="w-6 h-6 text-rose-400" />, label: 'Camera', action: () => handleSendMessage('', 'image') },
                  { icon: <FileDigit className="w-6 h-6 text-indigo-400" />, label: 'Document', action: () => handleSendMessage('', 'file') },
                  { icon: <MapPin className="w-6 h-6 text-emerald-400" />, label: 'Location', action: () => handleSendMessage('', 'location') },
                ].map((item, i) => (
                  <button key={i} onClick={item.action} className="flex flex-col items-center gap-2 group">
                    <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center group-hover:bg-white/10 transition-colors">
                      {item.icon}
                    </div>
                    <span className="text-[10px] text-zinc-400 font-medium">{item.label}</span>
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>

          <div className="flex items-end gap-2 sm:gap-3">
            <motion.button 
              {...hapticProps} 
              onClick={() => setShowAttachments(!showAttachments)}
              className={`p-3 rounded-2xl transition-all ${showAttachments ? 'bg-indigo-500/20 text-indigo-400' : 'bg-white/5 hover:bg-white/10 text-zinc-400'}`}
            >
              <Plus className={`w-5 h-5 transition-transform ${showAttachments ? 'rotate-45' : ''}`} />
            </motion.button>
            <div className="flex-1 relative bg-white/5 border border-white/10 rounded-2xl flex items-end">
              <textarea 
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                placeholder="Message..." 
                className="w-full bg-transparent py-3 px-4 text-sm text-white placeholder-zinc-500 focus:outline-none resize-none max-h-32 min-h-[44px]"
                rows={1}
                onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendMessage(); } }}
              />
              <motion.button {...hapticProps} className="p-3 text-zinc-500 hover:text-indigo-400 transition-colors shrink-0">
                <Smile className="w-5 h-5" />
              </motion.button>
            </div>
            {messageInput.trim() ? (
              <motion.button 
                {...hapticProps} onClick={() => handleSendMessage()}
                className="p-3 bg-indigo-500 rounded-2xl text-white shadow-lg shadow-indigo-500/20 shrink-0"
              >
                <Send className="w-5 h-5" />
              </motion.button>
            ) : (
              <motion.button {...hapticProps} className="p-3 bg-white/5 rounded-2xl text-zinc-400 hover:text-white shrink-0">
                <Mic className="w-5 h-5" />
              </motion.button>
            )}
          </div>
        </div>
      </motion.div>
    );
  };

  const renderChatList = () => (
    <motion.div 
      key="chat-list"
      initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}
      className="max-w-2xl mx-auto space-y-6"
    >
      <header className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black text-white">Messages</h2>
          <p className="text-xs text-zinc-500 font-medium uppercase tracking-widest">Connect & Share</p>
        </div>
        <div className="flex gap-2">
          <motion.button {...hapticProps} className="p-3 bg-white/5 hover:bg-white/10 rounded-2xl text-zinc-400 transition-all group relative">
            <Users className="w-5 h-5" />
            <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 bg-zinc-800 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">New Group</span>
          </motion.button>
          <motion.button {...hapticProps} className="p-3 bg-indigo-500 rounded-2xl text-white shadow-lg shadow-indigo-500/20 group relative">
            <Edit3 className="w-5 h-5" />
            <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 bg-zinc-800 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">New Message</span>
          </motion.button>
        </div>
      </header>

      <div className="relative group">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-500 group-focus-within:text-indigo-400 transition-colors" />
        <input 
          type="text" 
          placeholder="Search messages, files, locations..." 
          className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-indigo-500/50 transition-all"
        />
      </div>

      <div className="space-y-2">
        <AnimatePresence mode="popLayout">
          {chats.map((chat) => {
            const lastMsg = chat.messages[chat.messages.length - 1];
            const isOptionsOpen = chatOptionsId === chat.id;

            return (
              <div key={chat.id} className="relative">
                <motion.div
                  {...hapticProps}
                  onClick={() => !isOptionsOpen && setSelectedChat(chat)}
                  onContextMenu={(e) => { e.preventDefault(); setChatOptionsId(isOptionsOpen ? null : chat.id); }}
                  className={`w-full flex items-center justify-between p-4 rounded-3xl transition-all group cursor-pointer
                    ${isOptionsOpen ? 'bg-white/10 border-white/20' : 'bg-white/5 border-white/5 hover:border-white/10 hover:bg-white/[0.07]'}`}
                >
                  <div className="flex items-center gap-4 flex-1 min-w-0">
                    <div className="relative shrink-0">
                      <div className="w-14 h-14 rounded-full relative overflow-hidden border-2 border-white/10 group-hover:border-indigo-500/50 transition-all">
                        <Image src={chat.user.avatar} alt={chat.user.name} fill className="object-cover" referrerPolicy="no-referrer" />
                      </div>
                      {chat.user.isOnline && (
                        <div className="absolute bottom-0 right-0 w-4 h-4 bg-emerald-500 border-4 border-zinc-950 rounded-full" />
                      )}
                    </div>
                    <div className="text-left flex-1 min-w-0">
                      <p className="text-sm font-bold text-white group-hover:text-indigo-400 transition-colors flex items-center gap-2">
                        {chat.user.name}
                        {chat.isGroup && <Users className="w-3 h-3 text-zinc-500" />}
                      </p>
                      <p className="text-xs text-zinc-500 truncate mt-0.5">
                        {lastMsg?.type === 'text' ? lastMsg.text : `Sent a ${lastMsg?.type}`}
                      </p>
                    </div>
                  </div>
                  <div className="text-right space-y-2 shrink-0 ml-4 flex flex-col items-end">
                    <p className="text-[10px] text-zinc-600 font-medium">{lastMsg?.time}</p>
                    {chat.unreadCount > 0 && (
                      <div className="bg-indigo-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-lg shadow-indigo-500/20">
                        {chat.unreadCount}
                      </div>
                    )}
                  </div>
                </motion.div>

                {/* Context Menu / Options */}
                <AnimatePresence>
                  {isOptionsOpen && (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.95, y: -10 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95, y: -10 }}
                      className="absolute top-full right-4 mt-2 w-48 bg-zinc-900 border border-white/10 rounded-2xl shadow-2xl overflow-hidden z-30"
                    >
                      <button className="w-full flex items-center gap-3 px-4 py-3 text-sm text-white hover:bg-white/5 transition-colors">
                        <Archive className="w-4 h-4 text-zinc-400" /> Archive Chat
                      </button>
                      <button className="w-full flex items-center gap-3 px-4 py-3 text-sm text-white hover:bg-white/5 transition-colors">
                        <BellOff className="w-4 h-4 text-zinc-400" /> Mute Notifications
                      </button>
                      <button className="w-full flex items-center gap-3 px-4 py-3 text-sm text-red-400 hover:bg-red-500/10 transition-colors border-t border-white/5">
                        <Trash2 className="w-4 h-4" /> Delete Chat
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </AnimatePresence>
      </div>
      
      {/* Overlay to close options */}
      {chatOptionsId && (
        <div className="fixed inset-0 z-20" onClick={() => setChatOptionsId(null)} />
      )}
    </motion.div>
  );

  return (
    <AnimatePresence mode="wait">
      {selectedChat ? renderActiveChat() : renderChatList()}
    </AnimatePresence>
  );
}
