import React from 'react';

export default function Logo({ className = "w-10 h-10" }: { className?: string }) {
  return (
    <div className={`relative flex items-center justify-center ${className}`}>
      {/* Soft glow effect */}
      <div className="absolute inset-0 bg-[#00E5FF] blur-xl opacity-30 rounded-full" />
      
      {/* Main Logo Container */}
      <div className="relative w-full h-full rounded-[28%] bg-gradient-to-br from-[#5254FF] to-[#7172FA] shadow-[0_8px_32px_rgba(82,84,255,0.4)] flex items-center justify-center overflow-hidden border border-white/10 backdrop-blur-md">
        
        {/* Inner Glassmorphism Highlight */}
        <div className="absolute top-0 left-0 right-0 h-1/2 bg-gradient-to-b from-white/20 to-transparent" />
        
        {/* The Letter 'R' with Play Button */}
        <svg viewBox="0 0 100 100" className="w-[60%] h-[60%] drop-shadow-lg z-10">
          <defs>
            <linearGradient id="rGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="100%" stopColor="#E0E0FF" />
            </linearGradient>
            <linearGradient id="playGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#00E5FF" />
              <stop offset="100%" stopColor="#00B3CC" />
            </linearGradient>
            <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="2" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>
          
          {/* R Stem */}
          <path 
            d="M 30 20 L 30 80" 
            stroke="url(#rGradient)" 
            strokeWidth="14" 
            strokeLinecap="round" 
          />
          
          {/* R Loop */}
          <path 
            d="M 30 20 C 65 20, 75 35, 65 50 C 55 65, 30 50, 30 50" 
            fill="none"
            stroke="url(#rGradient)" 
            strokeWidth="14" 
            strokeLinecap="round" 
            strokeLinejoin="round"
          />
          
          {/* R Leg */}
          <path 
            d="M 45 50 L 70 80" 
            stroke="url(#rGradient)" 
            strokeWidth="14" 
            strokeLinecap="round" 
          />
          
          {/* Play Button (Triangle) integrated into the loop */}
          <polygon 
            points="45,30 45,40 55,35" 
            fill="url(#playGradient)" 
            filter="url(#glow)"
          />
        </svg>
      </div>
    </div>
  );
}
