'use client';

import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Image from 'next/image';
import { 
  X, 
  Music, 
  Type, 
  PenTool, 
  Sticker, 
  Crop, 
  Settings, 
  ChevronRight,
  Send,
  Users,
  Globe,
  Check,
  Play,
  Pause
} from 'lucide-react';

interface StoryComposerProps {
  onClose: () => void;
}

export default function StoryComposer({ onClose }: StoryComposerProps) {
  const [image, setImage] = useState<string | null>("https://picsum.photos/seed/storybg/1080/1920");
  const [activeTool, setActiveTool] = useState<'none' | 'text' | 'draw' | 'music' | 'stickers' | 'crop' | 'settings'>('none');
  const [isHighQuality, setIsHighQuality] = useState(true);
  const [privacy, setPrivacy] = useState<'public' | 'close_friends'>('public');
  const [isPlayingMusic, setIsPlayingMusic] = useState(false);

  const hapticProps = {
    whileTap: { scale: 0.9 },
    transition: { type: "spring" as const, stiffness: 400, damping: 17 }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: '100%' }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: '100%' }}
      transition={{ type: "spring", damping: 25, stiffness: 200 }}
      className="fixed inset-0 z-[100] bg-black flex flex-col"
    >
      {/* Top Controls */}
      <div className="absolute top-0 inset-x-0 p-6 flex items-center justify-between z-20 bg-gradient-to-b from-black/60 to-transparent">
        <button onClick={onClose} className="p-2 bg-black/20 backdrop-blur-md rounded-full text-white hover:bg-white/20 transition-colors">
          <X className="w-6 h-6" />
        </button>
        
        <div className="flex items-center gap-4">
          <button onClick={() => setActiveTool('music')} className="p-2 text-white drop-shadow-md hover:scale-110 transition-transform"><Music className="w-6 h-6" /></button>
          <button onClick={() => setActiveTool('text')} className="p-2 text-white drop-shadow-md hover:scale-110 transition-transform"><Type className="w-6 h-6" /></button>
          <button onClick={() => setActiveTool('draw')} className="p-2 text-white drop-shadow-md hover:scale-110 transition-transform"><PenTool className="w-6 h-6" /></button>
          <button onClick={() => setActiveTool('stickers')} className="p-2 text-white drop-shadow-md hover:scale-110 transition-transform"><Sticker className="w-6 h-6" /></button>
          <button onClick={() => setActiveTool('crop')} className="p-2 text-white drop-shadow-md hover:scale-110 transition-transform"><Crop className="w-6 h-6" /></button>
          <button onClick={() => setActiveTool('settings')} className="p-2 text-white drop-shadow-md hover:scale-110 transition-transform"><Settings className="w-6 h-6" /></button>
        </div>
      </div>

      {/* Main Canvas */}
      <div className="flex-1 relative overflow-hidden bg-zinc-900 rounded-b-[40px]">
        {image && (
          <Image 
            src={image} 
            alt="Story Draft" 
            fill 
            className="object-cover"
            referrerPolicy="no-referrer"
          />
        )}
        
        {/* Active Tool Overlay */}
        <AnimatePresence>
          {activeTool === 'music' && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 20 }}
              className="absolute bottom-32 inset-x-4 bg-black/60 backdrop-blur-xl rounded-3xl p-4 border border-white/10"
            >
              <h4 className="text-white font-bold mb-4 flex items-center gap-2"><Music className="w-4 h-4 text-indigo-400" /> Music Library (15s limit)</h4>
              <div className="space-y-2">
                {[1, 2, 3].map(i => (
                  <div key={i} className="flex items-center justify-between p-2 hover:bg-white/10 rounded-xl cursor-pointer transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-indigo-500/20 rounded-lg flex items-center justify-center">
                        <Music className="w-5 h-5 text-indigo-400" />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-white">Trending Track {i}</p>
                        <p className="text-xs text-zinc-400">Artist Name</p>
                      </div>
                    </div>
                    <button className="p-2 text-white hover:text-indigo-400 transition-colors">
                      <Play className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
              <button onClick={() => setActiveTool('none')} className="mt-4 w-full py-2 bg-white/10 rounded-xl text-white font-bold text-sm">Done</button>
            </motion.div>
          )}

          {activeTool === 'settings' && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 20 }}
              className="absolute bottom-32 inset-x-4 bg-black/80 backdrop-blur-xl rounded-3xl p-6 border border-white/10 space-y-6"
            >
              <h4 className="text-white font-bold text-lg">Story Settings</h4>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium">High Quality Upload</p>
                    <p className="text-xs text-zinc-400">Upload in highest resolution</p>
                  </div>
                  <button 
                    onClick={() => setIsHighQuality(!isHighQuality)}
                    className={`w-12 h-6 rounded-full transition-colors relative ${isHighQuality ? 'bg-indigo-500' : 'bg-zinc-700'}`}
                  >
                    <motion.div 
                      layout
                      className="w-5 h-5 bg-white rounded-full absolute top-0.5 left-0.5"
                      animate={{ x: isHighQuality ? 24 : 0 }}
                    />
                  </button>
                </div>

                <div className="pt-4 border-t border-white/10">
                  <p className="text-white font-medium mb-3">Privacy</p>
                  <div className="space-y-2">
                    <button 
                      onClick={() => setPrivacy('public')}
                      className={`w-full flex items-center justify-between p-3 rounded-xl border transition-colors
                        ${privacy === 'public' ? 'border-indigo-500 bg-indigo-500/10' : 'border-white/10 bg-white/5'}`}
                    >
                      <div className="flex items-center gap-3">
                        <Globe className={`w-5 h-5 ${privacy === 'public' ? 'text-indigo-400' : 'text-zinc-400'}`} />
                        <span className="text-sm font-medium text-white">Public</span>
                      </div>
                      {privacy === 'public' && <Check className="w-4 h-4 text-indigo-400" />}
                    </button>
                    <button 
                      onClick={() => setPrivacy('close_friends')}
                      className={`w-full flex items-center justify-between p-3 rounded-xl border transition-colors
                        ${privacy === 'close_friends' ? 'border-emerald-500 bg-emerald-500/10' : 'border-white/10 bg-white/5'}`}
                    >
                      <div className="flex items-center gap-3">
                        <Users className={`w-5 h-5 ${privacy === 'close_friends' ? 'text-emerald-400' : 'text-zinc-400'}`} />
                        <span className="text-sm font-medium text-white">Close Friends</span>
                      </div>
                      {privacy === 'close_friends' && <Check className="w-4 h-4 text-emerald-400" />}
                    </button>
                  </div>
                </div>
              </div>
              <button onClick={() => setActiveTool('none')} className="w-full py-3 bg-white text-black rounded-xl font-bold">Done</button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Bottom Actions */}
      <div className="p-4 pb-8 flex items-center gap-3 bg-black">
        <motion.button 
          {...hapticProps}
          className="flex-1 bg-zinc-900 hover:bg-zinc-800 text-white rounded-full py-4 px-6 flex items-center justify-between transition-colors border border-white/10"
        >
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-500 flex items-center justify-center">
              <Image src="https://picsum.photos/seed/me/100" alt="Me" width={20} height={20} className="rounded-full" />
            </div>
            <span className="font-bold text-sm">Your Story</span>
          </div>
        </motion.button>
        
        <motion.button 
          {...hapticProps}
          className="flex-1 bg-indigo-500 hover:bg-indigo-600 text-white rounded-full py-4 px-6 flex items-center justify-between transition-colors shadow-lg shadow-indigo-500/20"
        >
          <span className="font-bold text-sm">Send To</span>
          <ChevronRight className="w-5 h-5" />
        </motion.button>
      </div>
    </motion.div>
  );
}
