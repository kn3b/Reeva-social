'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Image from 'next/image';
import { X, Heart, MessageCircle, Share2, Users, Gift, Smile, Send, Eye, Star, ChevronRight, Crown, Shield } from 'lucide-react';

export default function LiveStreaming({ onClose, onGoToProfile }: { onClose: () => void, onGoToProfile?: () => void }) {
  const [comments, setComments] = useState<{id: number, user: string, text: string, isSupporter?: boolean}[]>([]);
  const [hearts, setHearts] = useState<{id: number, x: number, color: string}[]>([]);
  const [isFollowing, setIsFollowing] = useState(false);
  const [showGiftMenu, setShowGiftMenu] = useState(false);

  const hapticProps = {
    whileTap: { scale: 0.9 },
    transition: { type: "spring" as const, stiffness: 400, damping: 17 }
  };

  const colors = ['text-rose-500', 'text-indigo-500', 'text-amber-500', 'text-emerald-500', 'text-purple-500'];

  // Simulate incoming comments
  useEffect(() => {
    const interval = setInterval(() => {
      setComments(prev => {
        const isSupporter = Math.random() > 0.7;
        const newComments = [...prev, { 
          id: Date.now(), 
          user: `User${Math.floor(Math.random() * 1000)}`, 
          text: ['Awesome!', 'Love this 🔥', 'Hello from Dubai!', 'Can you explain that again?', 'Wow!'][Math.floor(Math.random() * 5)],
          isSupporter
        }];
        if (newComments.length > 6) newComments.shift();
        return newComments;
      });
    }, 1500);
    return () => clearInterval(interval);
  }, []);

  const handleHeart = useCallback(() => {
    const id = Date.now();
    const color = colors[Math.floor(Math.random() * colors.length)];
    setHearts(prev => [...prev, { id, x: Math.random() * 60 - 30, color }]);
    setTimeout(() => {
      setHearts(prev => prev.filter(h => h.id !== id));
    }, 2000);
  }, [colors]);

  const handleSendGift = (giftName: string) => {
    setShowGiftMenu(false);
    // Add a special comment for the gift
    setComments(prev => [...prev, {
      id: Date.now(),
      user: 'You',
      text: `Sent a ${giftName}! 🎁✨`,
      isSupporter: true
    }]);
    // Trigger multiple hearts
    for(let i=0; i<5; i++) {
      setTimeout(handleHeart, i * 100);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: '100%' }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: '100%' }}
      transition={{ type: "spring", damping: 25, stiffness: 200 }}
      className="fixed inset-0 z-[100] bg-black flex items-center justify-center"
    >
      <div className="w-full max-w-md h-full relative bg-zinc-900 overflow-hidden">
        {/* Live Video Feed */}
        <Image 
          src="https://picsum.photos/seed/live/1080/1920" 
          alt="Live Stream" 
          fill 
          className="object-cover"
          referrerPolicy="no-referrer"
        />
        
        {/* Overlays */}
        <div className="absolute inset-x-0 top-0 h-40 bg-gradient-to-b from-black/80 to-transparent pointer-events-none" />
        <div className="absolute inset-x-0 bottom-0 h-80 bg-gradient-to-t from-black/90 via-black/50 to-transparent pointer-events-none" />

        {/* AI Moderation Banner */}
        <div className="absolute top-24 inset-x-4 z-20">
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1 }}
            className="bg-indigo-500/20 backdrop-blur-md border border-indigo-500/30 rounded-xl p-3 flex items-start gap-3 shadow-lg"
          >
            <Shield className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-xs font-bold text-white mb-0.5">AI Moderation Active</p>
              <p className="text-[10px] text-zinc-300 leading-relaxed">
                This stream is monitored by AI to ensure compliance with global community standards. Hate speech, harassment, and inappropriate content will result in immediate termination.
              </p>
            </div>
          </motion.div>
        </div>

        {/* Header */}
        <div className="absolute top-0 inset-x-0 p-6 flex items-center justify-between z-20">
          <div 
            onClick={() => {
              if (onGoToProfile) {
                onClose();
                onGoToProfile();
              }
            }}
            className="flex items-center gap-3 bg-black/40 backdrop-blur-md rounded-full pr-2 p-1 border border-white/10 cursor-pointer group hover:bg-black/60 transition-colors"
          >
            <div className="w-10 h-10 rounded-full overflow-hidden relative border-2 border-rose-500">
              <Image src="https://picsum.photos/seed/creator/100" alt="Creator" fill className="object-cover" />
            </div>
            <div className="flex flex-col justify-center">
              <p className="text-sm font-bold text-white flex items-center gap-1">Alex Rivera <ChevronRight className="w-3 h-3 text-white/50 group-hover:text-white transition-colors" /></p>
              <div className="flex items-center gap-2">
                <span className="bg-rose-500 text-white text-[8px] font-black px-1.5 py-0.5 rounded uppercase tracking-wider animate-pulse">Live</span>
                <span className="flex items-center gap-1 text-[10px] text-white/80 font-medium"><Eye className="w-3 h-3" /> 12.4k</span>
              </div>
            </div>
            <motion.button 
              {...hapticProps}
              onClick={(e) => { e.stopPropagation(); setIsFollowing(!isFollowing); }}
              className={`ml-2 px-4 py-1.5 rounded-full text-[10px] font-bold transition-all ${isFollowing ? 'bg-white/20 text-white' : 'bg-indigo-500 text-white shadow-[0_0_10px_rgba(79,70,229,0.5)]'}`}
            >
              {isFollowing ? 'Following' : 'Follow'}
            </motion.button>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex -space-x-2 mr-2">
              {[1,2,3].map(i => (
                <div key={i} className="w-6 h-6 rounded-full border border-black overflow-hidden relative z-10">
                  <Image src={`https://picsum.photos/seed/viewer${i}/50`} alt="Viewer" fill className="object-cover" />
                </div>
              ))}
              <div className="w-6 h-6 rounded-full border border-black bg-zinc-800 flex items-center justify-center text-[8px] font-bold text-white relative z-0">
                +12k
              </div>
            </div>
            <button onClick={onClose} className="p-2 bg-black/40 backdrop-blur-md rounded-full text-white hover:bg-white/20 border border-white/10 transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Top Supporters Banner */}
        <div className="absolute top-24 left-6 right-6 z-20 flex gap-2 overflow-x-auto scrollbar-hide">
          <div className="flex items-center gap-2 bg-gradient-to-r from-amber-500/20 to-orange-500/20 backdrop-blur-md border border-amber-500/30 rounded-full px-3 py-1.5 shrink-0">
            <Crown className="w-3 h-3 text-amber-400" />
            <span className="text-[10px] font-bold text-amber-400">Top 1: Sarah</span>
          </div>
          <div className="flex items-center gap-2 bg-white/10 backdrop-blur-md border border-white/10 rounded-full px-3 py-1.5 shrink-0">
            <Star className="w-3 h-3 text-zinc-300" />
            <span className="text-[10px] font-bold text-zinc-300">Top 2: Mike</span>
          </div>
        </div>

        {/* Floating Hearts Animation */}
        <div className="absolute bottom-32 right-6 w-16 h-64 pointer-events-none z-10">
          <AnimatePresence>
            {hearts.map(heart => (
              <motion.div
                key={heart.id}
                initial={{ opacity: 1, y: 0, x: 0, scale: 0.5 }}
                animate={{ opacity: 0, y: -250, x: heart.x, scale: 1.5 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 2.5, ease: "easeOut" }}
                className={`absolute bottom-0 ${heart.color}`}
              >
                <Heart className="w-8 h-8 fill-current drop-shadow-lg" />
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Comments Area */}
        <div className="absolute bottom-24 left-0 right-20 p-6 space-y-3 z-20 max-h-[40vh] overflow-y-auto scrollbar-hide mask-image-gradient">
          <AnimatePresence>
            {comments.map(comment => (
              <motion.div 
                key={comment.id}
                initial={{ opacity: 0, x: -20, scale: 0.9 }}
                animate={{ opacity: 1, x: 0, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="flex items-start gap-2"
              >
                <div className={`w-8 h-8 rounded-full shrink-0 flex items-center justify-center text-[10px] font-bold text-white relative overflow-hidden
                  ${comment.isSupporter ? 'bg-gradient-to-br from-amber-400 to-orange-500 border border-amber-300' : 'bg-gradient-to-br from-indigo-500 to-purple-500'}`}
                >
                  {comment.user.charAt(0)}
                  {comment.isSupporter && <Crown className="absolute -top-1 -right-1 w-3 h-3 text-white drop-shadow-md" />}
                </div>
                <div className={`backdrop-blur-md rounded-2xl rounded-tl-none px-4 py-2 border 
                  ${comment.isSupporter ? 'bg-amber-500/10 border-amber-500/30' : 'bg-black/40 border-white/10'}`}
                >
                  <p className={`text-[10px] font-bold mb-0.5 flex items-center gap-1
                    ${comment.isSupporter ? 'text-amber-400' : 'text-zinc-400'}`}
                  >
                    {comment.user}
                    {comment.isSupporter && <Star className="w-3 h-3 fill-current" />}
                  </p>
                  <p className="text-sm text-white">{comment.text}</p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Gift Menu Overlay */}
        <AnimatePresence>
          {showGiftMenu && (
            <>
              <motion.div 
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                onClick={() => setShowGiftMenu(false)}
                className="absolute inset-0 bg-black/60 backdrop-blur-sm z-30"
              />
              <motion.div 
                initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }}
                className="absolute inset-x-0 bottom-0 bg-zinc-900 rounded-t-[32px] p-6 z-40 border-t border-white/10"
              >
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-white font-bold text-lg">Send a Gift</h3>
                  <div className="flex items-center gap-2 bg-white/10 px-3 py-1.5 rounded-full">
                    <Star className="w-4 h-4 text-amber-400 fill-current" />
                    <span className="text-sm font-bold text-white">1,250</span>
                  </div>
                </div>
                <div className="grid grid-cols-4 gap-4">
                  {[
                    { name: 'Rose', icon: '🌹', cost: 10 },
                    { name: 'Heart', icon: '💖', cost: 50 },
                    { name: 'Crown', icon: '👑', cost: 100 },
                    { name: 'Rocket', icon: '🚀', cost: 500 },
                    { name: 'Diamond', icon: '💎', cost: 1000 },
                    { name: 'Fire', icon: '🔥', cost: 20 },
                    { name: 'Star', icon: '⭐', cost: 30 },
                    { name: 'Trophy', icon: '🏆', cost: 200 },
                  ].map(gift => (
                    <motion.button 
                      key={gift.name}
                      {...hapticProps}
                      onClick={() => handleSendGift(gift.name)}
                      className="flex flex-col items-center gap-2 p-3 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/5 transition-colors"
                    >
                      <span className="text-3xl drop-shadow-lg">{gift.icon}</span>
                      <span className="text-[10px] text-zinc-400 font-medium">{gift.name}</span>
                      <span className="text-[10px] text-amber-400 font-bold flex items-center gap-0.5"><Star className="w-2 h-2 fill-current" /> {gift.cost}</span>
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>

        {/* Bottom Bar */}
        <div className="absolute bottom-0 inset-x-0 p-6 flex items-center gap-3 z-20">
          <div className="flex-1 relative">
            <input 
              type="text" 
              placeholder="Comment..." 
              className="w-full bg-black/40 backdrop-blur-md border border-white/20 rounded-full py-3 pl-5 pr-12 text-sm text-white placeholder-white/60 focus:outline-none focus:border-indigo-500 transition-all"
            />
            <button className="absolute right-3 top-1/2 -translate-y-1/2 text-white/60 hover:text-white transition-colors">
              <Smile className="w-5 h-5" />
            </button>
          </div>
          <motion.button 
            {...hapticProps} 
            onClick={() => setShowGiftMenu(true)}
            className="p-3 bg-gradient-to-r from-amber-400 to-orange-500 rounded-full text-white shadow-[0_0_15px_rgba(251,191,36,0.5)] relative overflow-hidden group"
          >
            <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform" />
            <Gift className="w-6 h-6 relative z-10" />
          </motion.button>
          <motion.button 
            {...hapticProps} 
            onClick={handleHeart} 
            className="p-3 bg-black/40 backdrop-blur-md border border-white/20 rounded-full text-white hover:bg-white/20 transition-colors"
          >
            <Heart className="w-6 h-6" />
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
}
