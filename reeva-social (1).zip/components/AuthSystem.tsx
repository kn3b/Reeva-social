'use client';

import React, { useState } from 'react';
import { motion } from 'motion/react';
import ReevaLogo from './ReevaLogo';
import { Mail, Lock, ArrowRight, Github, Twitter, User, Calendar, CheckSquare, Square } from 'lucide-react';

export default function AuthSystem({ onLogin }: { onLogin: () => void }) {
  const [isLogin, setIsLogin] = useState(true);
  const [agreedToTerms, setAgreedToTerms] = useState(false);

  const handleAuth = () => {
    if (!isLogin && !agreedToTerms) {
      alert("You must agree to the Terms of Service and Privacy Policy to create an account.");
      return;
    }
    onLogin();
  };

  return (
    <div className="min-h-screen bg-zinc-950 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-500/20 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-500/20 rounded-full blur-[120px] pointer-events-none" />

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-white/5 backdrop-blur-2xl border border-white/10 rounded-[40px] p-8 shadow-2xl relative z-10"
      >
        <div className="flex flex-col items-center mb-8">
          <ReevaLogo className="w-20 h-20 mb-6" />
          <h2 className="text-3xl font-black text-white tracking-tight">
            {isLogin ? 'Welcome Back' : 'Join Reeva'}
          </h2>
          <p className="text-zinc-400 text-sm mt-2 text-center">
            {isLogin ? 'Enter your details to access your account.' : 'Create an account to connect with the world.'}
          </p>
        </div>

        <div className="space-y-4">
          {!isLogin && (
            <>
              <div className="relative">
                <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
                  <User className="w-5 h-5 text-zinc-500" />
                </div>
                <input 
                  type="text" 
                  placeholder="Full Name" 
                  className="w-full bg-black/20 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-white placeholder-zinc-500 focus:outline-none focus:border-indigo-500/50 transition-all"
                />
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
                  <Calendar className="w-5 h-5 text-zinc-500" />
                </div>
                <input 
                  type="date" 
                  placeholder="Date of Birth" 
                  className="w-full bg-black/20 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-white placeholder-zinc-500 focus:outline-none focus:border-indigo-500/50 transition-all [color-scheme:dark]"
                />
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
                  <User className="w-5 h-5 text-zinc-500" />
                </div>
                <select 
                  className="w-full bg-black/20 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-white placeholder-zinc-500 focus:outline-none focus:border-indigo-500/50 transition-all appearance-none"
                  defaultValue=""
                >
                  <option value="" disabled className="bg-zinc-900 text-zinc-500">Select Gender</option>
                  <option value="male" className="bg-zinc-900">Male</option>
                  <option value="female" className="bg-zinc-900">Female</option>
                  <option value="other" className="bg-zinc-900">Other</option>
                  <option value="prefer_not_to_say" className="bg-zinc-900">Prefer not to say</option>
                </select>
              </div>
            </>
          )}
          <div className="relative">
            <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
              <Mail className="w-5 h-5 text-zinc-500" />
            </div>
            <input 
              type="email" 
              placeholder="Email Address" 
              className="w-full bg-black/20 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-white placeholder-zinc-500 focus:outline-none focus:border-indigo-500/50 transition-all"
            />
          </div>
          <div className="relative">
            <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
              <Lock className="w-5 h-5 text-zinc-500" />
            </div>
            <input 
              type="password" 
              placeholder="Password" 
              className="w-full bg-black/20 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-white placeholder-zinc-500 focus:outline-none focus:border-indigo-500/50 transition-all"
            />
          </div>

          {!isLogin && (
            <div 
              className="flex items-start gap-3 mt-4 cursor-pointer group"
              onClick={() => setAgreedToTerms(!agreedToTerms)}
            >
              <div className="mt-1 text-indigo-400">
                {agreedToTerms ? <CheckSquare className="w-5 h-5" /> : <Square className="w-5 h-5" />}
              </div>
              <p className="text-xs text-zinc-400 leading-relaxed">
                I agree to the <span className="text-indigo-400 hover:underline">Terms of Service</span>, <span className="text-indigo-400 hover:underline">Privacy Policy</span>, and <span className="text-indigo-400 hover:underline">Community Guidelines</span>. I confirm that I am of legal age to use this service.
              </p>
            </div>
          )}

          {isLogin && (
            <div className="flex justify-end">
              <button className="text-xs text-indigo-400 font-medium hover:text-indigo-300 transition-colors">
                Forgot Password?
              </button>
            </div>
          )}

          <motion.button 
            whileTap={{ scale: 0.98 }}
            onClick={handleAuth}
            className={`w-full py-4 rounded-2xl text-white font-bold flex items-center justify-center gap-2 group transition-all
              ${!isLogin && !agreedToTerms 
                ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed' 
                : 'bg-gradient-to-r from-[#5254FF] to-[#7172FA] shadow-[0_0_20px_rgba(82,84,255,0.3)]'}`}
          >
            {isLogin ? 'Sign In' : 'Create Account'}
            <ArrowRight className={`w-5 h-5 transition-transform ${(!isLogin && !agreedToTerms) ? '' : 'group-hover:translate-x-1'}`} />
          </motion.button>
        </div>

        <div className="mt-8 pt-8 border-t border-white/10">
          <p className="text-center text-xs text-zinc-500 mb-4 uppercase tracking-widest font-bold">Or continue with</p>
          <div className="grid grid-cols-2 gap-4">
            <button className="py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl flex items-center justify-center gap-2 text-sm font-medium text-white transition-all">
              <Github className="w-5 h-5" /> GitHub
            </button>
            <button className="py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl flex items-center justify-center gap-2 text-sm font-medium text-white transition-all">
              <Twitter className="w-5 h-5 text-[#1DA1F2]" /> Twitter
            </button>
          </div>
        </div>

        <div className="mt-8 text-center">
          <p className="text-sm text-zinc-400">
            {isLogin ? "Don't have an account? " : "Already have an account? "}
            <button 
              onClick={() => setIsLogin(!isLogin)}
              className="text-indigo-400 font-bold hover:text-indigo-300 transition-colors"
            >
              {isLogin ? 'Sign Up' : 'Sign In'}
            </button>
          </p>
        </div>
      </motion.div>
    </div>
  );
}
