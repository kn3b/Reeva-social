'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  PlusSquare, 
  Users, 
  Play, 
  User, 
  LayoutDashboard,
  Bell,
  Search,
  Settings,
  MessageCircle,
  Compass,
  Wallet,
  Radio
} from 'lucide-react';
import Image from 'next/image';
import PostComposer from '@/components/PostComposer';
import PostSettings from '@/components/PostSettings';
import FollowersSystem from '@/components/FollowersSystem';
import StorySystem from '@/components/StorySystem';
import GeneralSettings from '@/components/GeneralSettings';
import PostCard from '@/components/PostCard';
import ReelsSystem from '@/components/ReelsSystem';
import ProfileSystem from '@/components/ProfileSystem';
import MessagesSystem from '@/components/MessagesSystem';
import NotificationsSystem from '@/components/NotificationsSystem';
import EditProfileSystem from '@/components/EditProfileSystem';
import ExploreSystem from '@/components/ExploreSystem';
import WalletSystem from '@/components/WalletSystem';
import LiveStreaming from '@/components/LiveStreaming';
import AuthSystem from '@/components/AuthSystem';
import ReevaLogo from '@/components/ReevaLogo';
import { LanguageProvider, useLanguage } from '@/contexts/LanguageContext';

type View = 'dashboard' | 'explore' | 'create' | 'followers' | 'reels' | 'profile' | 'public-profile' | 'settings' | 'messages' | 'notifications' | 'edit-profile' | 'wallet' | 'live';

function MainApp() {
  const [activeView, setActiveView] = useState<View>('dashboard');
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const { t } = useLanguage();

  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const currentTheme = mediaQuery.matches ? 'dark' : 'light';
    if (theme !== currentTheme) {
      setTimeout(() => setTheme(currentTheme), 0);
    }
    const handler = (e: MediaQueryListEvent) => setTheme(e.matches ? 'dark' : 'light');
    mediaQuery.addEventListener('change', handler);
    return () => mediaQuery.removeEventListener('change', handler);
  }, [theme]);

  const navItems = [
    { id: 'dashboard', label: t('feed'), icon: <LayoutDashboard className="w-5 h-5" /> },
    { id: 'explore', label: t('explore'), icon: <Compass className="w-5 h-5" /> },
    { id: 'reels', label: t('reels'), icon: <Play className="w-5 h-5" /> },
    { id: 'create', label: t('create'), icon: <PlusSquare className="w-5 h-5" /> },
    { id: 'messages', label: t('messages'), icon: <MessageCircle className="w-5 h-5" /> },
    { id: 'profile', label: t('profile'), icon: <User className="w-5 h-5" /> },
  ];

  const hapticProps = {
    whileTap: { scale: 0.95 },
    transition: { type: "spring" as const, stiffness: 400, damping: 17 }
  };

  return (
    <div className={`min-h-screen font-sans transition-colors duration-500 selection:bg-indigo-500/30
      ${theme === 'dark' ? 'bg-zinc-950 text-white' : 'bg-zinc-50 text-zinc-900'}`}>
      {/* Top Bar */}
      <header className={`sticky top-0 z-40 backdrop-blur-xl border-b transition-colors duration-500
        ${theme === 'dark' ? 'bg-zinc-950/80 border-white/5' : 'bg-white/80 border-zinc-200'}`}>
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <motion.div 
              {...hapticProps}
              onClick={() => setActiveView('dashboard')}
              className="cursor-pointer"
            >
              <ReevaLogo className="w-10 h-10" />
            </motion.div>
            <h1 className={`text-xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r 
              ${theme === 'dark' ? 'from-white to-zinc-400' : 'from-zinc-900 to-zinc-500'}`}>REEVA</h1>
          </div>
          
          <div className="hidden md:flex items-center gap-6">
            <div className="relative group">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500 group-focus-within:text-indigo-400 transition-colors" />
              <input 
                type="text" 
                placeholder={t('search')} 
                className={`border rounded-full py-2 pl-10 pr-4 text-sm focus:outline-none focus:border-indigo-500/50 transition-all w-64
                  ${theme === 'dark' ? 'bg-white/5 border-white/5 text-white' : 'bg-zinc-100 border-zinc-200 text-zinc-900'}`}
              />
            </div>
            <div className="flex items-center gap-4">
              <motion.button 
                {...hapticProps}
                onClick={() => setActiveView('live')}
                className={`p-2 transition-colors ${activeView === 'live' ? 'text-rose-500' : 'text-zinc-400 hover:text-white'}`}
              >
                <Radio className="w-5 h-5" />
              </motion.button>
              <motion.button 
                {...hapticProps}
                onClick={() => setActiveView('wallet')}
                className={`p-2 transition-colors ${activeView === 'wallet' ? 'text-emerald-400' : 'text-zinc-400 hover:text-white'}`}
              >
                <Wallet className="w-5 h-5" />
              </motion.button>
              <motion.button 
                {...hapticProps}
                onClick={() => setActiveView('notifications')}
                className={`p-2 transition-colors relative ${activeView === 'notifications' ? 'text-indigo-500' : 'text-zinc-400 hover:text-white'}`}
              >
                <Bell className="w-5 h-5" />
                <span className="absolute top-2 right-2 w-2 h-2 bg-indigo-500 rounded-full border-2 border-zinc-950" />
              </motion.button>
              <motion.button 
                {...hapticProps}
                onClick={() => setActiveView('settings')}
                className={`p-2 transition-colors ${activeView === 'settings' ? 'text-indigo-400' : 'text-zinc-400 hover:text-white'}`}
              >
                <Settings className="w-5 h-5" />
              </motion.button>
              <motion.div 
                {...hapticProps}
                onClick={() => setActiveView('profile')}
                className="w-8 h-8 rounded-full bg-zinc-800 border border-white/10 overflow-hidden relative cursor-pointer"
              >
                <Image 
                  src="https://picsum.photos/seed/me/100" 
                  alt="profile" 
                  fill 
                  className="object-cover"
                  referrerPolicy="no-referrer"
                />
              </motion.div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 pb-32">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeView}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {activeView === 'dashboard' && (
              <div className="space-y-8">
                <StorySystem />
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  <div className="lg:col-span-2 space-y-6">
                    <PostCard 
                      user={{ name: 'Sarah Chen', username: 'schen_art', avatar: 'https://picsum.photos/seed/2/100' }}
                      content="Just finished this new piece! The lighting in the studio today was absolutely perfect for capturing the textures. What do you guys think? #art #digitalart #creative"
                      image="https://picsum.photos/seed/art/1080/1080"
                      likes="1.2k"
                      comments="84"
                      onGoToProfile={() => setActiveView('public-profile')}
                    />
                    <PostCard 
                      user={{ name: 'Alex Rivera', username: 'arivera', avatar: 'https://picsum.photos/seed/1/100' }}
                      content="Exploring the hidden gems of the city. There's so much beauty in the mundane if you just look close enough. 🏙️✨"
                      image="https://picsum.photos/seed/city/1080/1080"
                      likes="842"
                      comments="32"
                      onGoToProfile={() => setActiveView('public-profile')}
                    />
                  </div>
                  <div className="space-y-6">
                    <div className="p-6 rounded-3xl bg-white/5 border border-white/5 space-y-4">
                      <h4 className="font-bold text-sm text-zinc-400 uppercase tracking-wider">Suggested for you</h4>
                      <FollowersSystem />
                    </div>
                  </div>
                </div>
              </div>
            )}
            {activeView === 'explore' && <ExploreSystem />}
            {activeView === 'create' && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <PostComposer />
                <PostSettings />
              </div>
            )}
            {activeView === 'reels' && <ReelsSystem />}
            {activeView === 'messages' && <MessagesSystem />}
            {activeView === 'profile' && <ProfileSystem onEdit={() => setActiveView('edit-profile')} />}
            {activeView === 'public-profile' && <ProfileSystem isPublic={true} />}
            {activeView === 'notifications' && <NotificationsSystem onOpenSettings={() => setActiveView('settings')} onGoToPost={() => setActiveView('dashboard')} />}
            {activeView === 'wallet' && <WalletSystem />}
            {activeView === 'live' && <LiveStreaming onClose={() => setActiveView('dashboard')} onGoToProfile={() => setActiveView('public-profile')} />}
            {activeView === 'edit-profile' && <EditProfileSystem onBack={() => setActiveView('profile')} />}
            {activeView === 'settings' && (
              <GeneralSettings 
                theme={theme} 
                setTheme={setTheme} 
                onEditProfile={() => setActiveView('edit-profile')}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50">
        <div className={`backdrop-blur-2xl border rounded-full p-2 flex items-center gap-1 shadow-2xl transition-colors duration-500
          ${theme === 'dark' ? 'bg-zinc-900/80 border-white/10' : 'bg-white/80 border-zinc-200'}`}>
          {navItems.map((item) => (
            <motion.button
              key={item.id}
              {...hapticProps}
              onClick={() => setActiveView(item.id as View)}
              className={`flex items-center gap-2 px-3 md:px-5 py-3 rounded-full transition-all relative
                ${activeView === item.id || (activeView === 'public-profile' && item.id === 'profile') ? 'text-white' : 'text-zinc-500 hover:text-indigo-500'}`}
            >
              {(activeView === item.id || (activeView === 'public-profile' && item.id === 'profile')) && (
                <motion.div 
                  layoutId="nav-pill"
                  className="absolute inset-0 bg-indigo-500 shadow-[0_0_20px_rgba(79,70,229,0.4)] rounded-full"
                  transition={{ type: "spring", stiffness: 400, damping: 30 }}
                />
              )}
              <span className="relative z-10">{item.icon}</span>
              {(activeView === item.id || (activeView === 'public-profile' && item.id === 'profile')) && (
                <motion.span 
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="relative z-10 text-xs md:text-sm font-bold hidden sm:block"
                >
                  {item.label}
                </motion.span>
              )}
            </motion.button>
          ))}
        </div>
      </nav>
    </div>
  );
}

export default function ReevaApp() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  return (
    <LanguageProvider>
      {!isAuthenticated ? (
        <AuthSystem onLogin={() => setIsAuthenticated(true)} />
      ) : (
        <MainApp />
      )}
    </LanguageProvider>
  );
}
