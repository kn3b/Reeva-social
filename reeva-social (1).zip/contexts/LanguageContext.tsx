'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';

export type Language = 'en' | 'ar' | 'fr' | 'es' | 'de' | 'zh' | 'ja';

const translations = {
  en: { feed: 'Feed', explore: 'Explore', reels: 'Reels', create: 'Create', messages: 'Messages', profile: 'Profile', settings: 'Settings', search: 'Search Reeva...', notifications: 'Notifications', wallet: 'Wallet', live: 'Live', logout: 'Logout' },
  ar: { feed: 'الرئيسية', explore: 'استكشاف', reels: 'ريلز', create: 'إنشاء', messages: 'الرسائل', profile: 'الملف الشخصي', settings: 'الإعدادات', search: 'ابحث في ريفا...', notifications: 'الإشعارات', wallet: 'المحفظة', live: 'بث مباشر', logout: 'تسجيل خروج' },
  fr: { feed: 'Flux', explore: 'Explorer', reels: 'Reels', create: 'Créer', messages: 'Messages', profile: 'Profil', settings: 'Paramètres', search: 'Rechercher...', notifications: 'Notifications', wallet: 'Portefeuille', live: 'Direct', logout: 'Déconnexion' },
  es: { feed: 'Inicio', explore: 'Explorar', reels: 'Reels', create: 'Crear', messages: 'Mensajes', profile: 'Perfil', settings: 'Ajustes', search: 'Buscar...', notifications: 'Notificaciones', wallet: 'Billetera', live: 'En vivo', logout: 'Cerrar sesión' },
  de: { feed: 'Startseite', explore: 'Entdecken', reels: 'Reels', create: 'Erstellen', messages: 'Nachrichten', profile: 'Profil', settings: 'Einstellungen', search: 'Suchen...', notifications: 'Benachrichtigungen', wallet: 'Brieftasche', live: 'Live', logout: 'Abmelden' },
  zh: { feed: '动态', explore: '探索', reels: '短视频', create: '创建', messages: '消息', profile: '我的', settings: '设置', search: '搜索...', notifications: '通知', wallet: '钱包', live: '直播', logout: '登出' },
  ja: { feed: 'フィード', explore: '検索', reels: 'リール', create: '作成', messages: 'メッセージ', profile: 'プロフィール', settings: '設定', search: '検索...', notifications: '通知', wallet: 'ウォレット', live: 'ライブ', logout: 'ログアウト' },
};

const LanguageContext = createContext<{ lang: Language; setLang: (l: Language) => void; t: (key: string) => string; dir: 'ltr' | 'rtl' } | null>(null);

export const LanguageProvider = ({ children }: { children: React.ReactNode }) => {
  const [lang, setLang] = useState<Language>('en');
  
  const t = (key: string) => {
    const langDict = translations[lang] as Record<string, string>;
    const enDict = translations['en'] as Record<string, string>;
    return langDict[key] || enDict[key] || key;
  };

  const dir = lang === 'ar' ? 'rtl' : 'ltr';

  useEffect(() => {
    document.documentElement.dir = dir;
    document.documentElement.lang = lang;
  }, [lang, dir]);

  return (
    <LanguageContext.Provider value={{ lang, setLang, t, dir }}>
      <div dir={dir}>{children}</div>
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error('useLanguage must be used within LanguageProvider');
  return ctx;
};
